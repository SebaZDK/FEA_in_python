import numpy as np
import math
# A finite element program in 2D by Sebastian Rosleff, inspired (heavily) by L.V.A's MALTAB 2D timoskenko beam program
# 3D version is coming soon, static calculation engine and force generation is already working

# Normal node springs are implemented
# Right now only static mode is enabled, as this is the primary goal (To be used in bachelors)
# The figure table is interactive, to pressing on the side legend disables the view elements

# Coordinates         x, y
# nodeCoor = 1 * np.array([[0, 0], [1, 0], [2, 0], [3, 0], [4, 0], [5, 0], [6, 0], [7, 0], [8, 0], [9, 0], [10, 0], [11, 0], [12, 0]
#                         , [13, 0], [14, 0], [15, 0], [16, 0], [17, 0], [18, 0], [19, 0], [20, 0], [21, 0], [22, 0]])  # Node coordinates
nodeCoor = np.array([[0, 0]])
elemVec = np.array([[0, 1]])
spacing = 0.1
num = 100
for i in range(num):
    nodeCoor = np.vstack([nodeCoor, [i + 1, 0]])
for i in range(1, num):
    elemVec = np.vstack([elemVec, [i, i + 1]])
nodeCoor = spacing * nodeCoor
# elemVec = np.array([[0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 6], [6, 7], [7, 8], [8, 9], [9, 10], [10, 11], [11, 12]
#                     ,[12, 13], [13, 14], [14, 15], [15, 16], [16, 17], [17, 18], [18, 19], [19, 20], [20, 21], [21, 22]])  # Nodes that are connected by elements
# nodeCoor = np.array([[0, 0], [1, 0], [2, 0]])
# elemVec = np.array([[0, 1], [1, 2]])  # Nodes that are connected by elements

# Material parameters (All values are in SI)-----------------------------------------------------
E = np.array([[2.1*10**11], [2.1 * 10 ** 11]])  # stiffness in N/m^2
nu = np.array([[0.3], [0.15]])  # Poisson's ratio
rho = np.array([[7850], [2500]])  # Density in kg/m^3
G = np.array([[E[0] * 10000/ (2 * (1 + nu[0]))], [E[1] / (2 * (1 + nu[1]))]])  # Shear modulus of the beam
# G = np.array([[E[0] / (2 * (1 + nu[0]))], [E[1] / (2 * (1 + nu[1]))]])
fy = np.array([[235*10**6], [40*10**6]])  # 'Yield' stress for steel and concrete C40.
radii = 0.05 # radius in meters

# Cross-sectional parameters----------------------------------------------
#          Area x and shear area in y
A = np.array([[0.1 * 0.1, (5 / 6) * 0.1 * 0.1],  # 1 is for a beam, 2 is for circular rod
              [((radii)**2) * np.pi, 2 * ((radii)**2) / np.pi]])

# 2nd moment of area in m^4 y
# Ibeam = np.array([[1.0 * 10 ** (-4)], [1.0 * 10 ** (-4)]])
Ibeam = np.array([[(0.1**4) / 12], [(np.pi/4) * ((radii)**4)]])  # 1st is beam, 2nd is rod

# Maximum distance from bending center to outer fiber:
zMax = np.array([[0.05], [radii]])  # For beam and circular tube


# Assignment of materials and cross-section parameters: (human numbers)
materialParameters = np.ones((len(elemVec)))  # Creates a vector storing the index of the material assigned
sectionParameters = 2 * np.ones((len(elemVec)))  # Same but for cross-sections

# Loads and boundary conditions-------------------------------------
# Put in as python numbers, so DOF 1 (x) is indexed as 0, DOF 2 (y) as 1
# Forces         Node , DOF, Magnitude  (Apply in N)
# forces = np.array([[3, 1, -1000 * 10 ** 3], [3, 0, 100 * 10 ** 3], [3, 2, 500 * 10 ** 3]])  # Forces to be applied to the model
# forces = np.array([[3, 1, -100 * 10 ** 3], [6, 0, 100 * 10 ** 3]])  # Forces to be applied to the model
# forces = np.array([[1, 1, -1000 * 10 ** 3], [1, 0, 1000 * 10 ** 3], [1, 2, 1000 * 10 ** 3], [3, 2, 1000 * 10 ** 3]])  # Forces to be applied to the model
# forces = np.array([[50, 1, -1 * 10 ** 3]])
# forces = np.array([[6, 1, -1 * 10 ** 3]])

# greenfieldForces = 'true'
greenfieldForces = 'false'
                 # d_ini (m) x,  y,    M , H (m) , D (m)
infoGFD = np.array([0,         -0.2,  0,   5,    radii])
stiffSoil = np.array([['1000 * math.log(xx + 1)', '10000 * math.log(xx + 1)', '1000 * math.log(xx + 1)']])  # Function for x, y, and moment in soil movement for transfer.

# Boundary conditions
# Displacement BD. node, DOF, imposed displacement
# dispBound = np.array([[0, 0, 0], [0, 1, 0], [6, 1, 0]])
dispBound = np.array([[0, 0, 0], [0, 1, 0], [0, 2, 0], [num, 0, 0], [num, 1, 0], [num, 2, 0]])
# dispBound = np.array([[0, 0, 0], [0, 1, 0], [num, 0, 0], [num, 1, 0]])
# dispBound = np.array([[0, 0, 0]])

# Elastic or full releases: Not implemented yet
#            Element, Node, DOF, Stiffness
# releaseDOF = np.array([[2, 0, 2, 0]])          # No duplicate entries
# releaseDOF = []  # np.array([[0, 0, 2, 100000]]) # Just need to remove the original DOF and it works then

# Standardised springs
#            Node, DOF, stiffness
# springs = np.array([[6, 1, 1.0 * 10**0], [6, 0, 1.0 * 10**0], [0, 1, 1.0 * 10**0]])
# springs = np.array([[0, 1, 1.0 * 10**0], [1, 1, 1.0 * 10**0]])
# springs = np.array([[0, 0, 1.0 * 10**4], [0, 1, 1.0 * 10**4], [1, 0, 1.0 * 10**4], [1, 1, 1.0 * 10**4], [2, 0, 1.0 * 10**4], [2, 1, 1.0 * 10**4],
#                     [3, 0, 1.0 * 10**4], [3, 1, 1.0 * 10**4], [4, 0, 1.0 * 10**4], [4, 1, 1.0 * 10**4], [5, 0, 1.0 * 10**4], [5, 1, 1.0 * 10**4],
#                     [6, 0, 1.0 * 10**4], [6, 1, 1.0 * 10**4]])
# springs = np.array([[0, 0, 1.0 * 10**4], [0, 1, 1.0 * 10**4], [2, 0, 1.0 * 10**4], [2, 1, 1.0 * 10**4], [3, 0, 1.0 * 10**4], [3, 1, 1.0 * 10**4]])
# springs = np.array([[0, 0, 1.0 * 10**10], [0, 1, 1.0 * 10**10], [0, 2, 1.0 * 10**3]])

# non - linear springs
#                     Force function,  max deformation (m), start def (m) step increase (m)
# linSprings = np.array([['2000*x[i] + 200', 1, 0.5, 0.05], ['2000', 10, 1, 0.1], ['20000', 1000, 100, 0.1]])  #, [1.0 * 10**3, 10**(-3), 10**3]])

# Node values for linSprings
#                Node, DOF
# nodeLin = np.array([[0, 1], [1, 1], [2, 1], [3, 1], [4, 1], [5, 1], [6, 1], [7, 1], [8, 1], [9, 1], [10, 1], [11, 1], [12, 1]
#                     , [13, 1], [14, 1], [15, 1], [16, 1], [17, 1], [18, 1], [19, 1], [20, 1], [21, 1], [22, 1]])
nodeLin = np.array([[0, 1]])
for i in range(num):
   nodeLin = np.vstack([nodeLin, [i + 1, 1]])

ID = 3      # Relatice density 3 = 0,3
HD = 50
E_ref = 120*10**6
P_ref = 100
phi = 32
gamma = 16000
H = radii * 2 * HD
m_sand = 0.5
# match ID:
#         case 3:
#             if HD < 70:
#                 Ngamma = 0.45 * HD
#             else:
#                 Ngamma = 32
#         case 5:
#             if HD < 100:
#                 Ngamma = 0.5 * HD
#             else:
#                 Ngamma = 55 - 0.01 * HD
#         case 9:
#             if HD < 100:
#                 Ngamma = 0.75 * HD
#             else:
#                 Ngamma = 80 - 0.03 * HD
Ngamma = 30

forceSoil = Ngamma * H * 2 * radii * gamma * spacing  # As everything is kN / m from OPTUM G2
print(forceSoil)
# print(forceSoil / 1000, 'force in kN per node', forceSoil/spacing, 'Force per meter')
tempES = ((gamma / 1000) * H * (1 - np.sin(phi * np.pi / 180))) / P_ref
Es = E_ref * (tempES**0.5)
# print(Es / 1000000, 'Stiffness in MPa*')
# Vesic stiffness of soil: K = 2*K inf
kNN = (1 - nu[0][0] * nu[0][0])

expr = np.power(Es * (2 * radii) ** 4 / (E[0][0] * Ibeam[1][0]), (1/12))
stiffnessSoil = 2 * 0.65 * expr * (Es / kNN) * spacing
# print(stiffnessSoil / 1000000, 'Stiffness for Springs in MPa')

#                 Tangent Stiffness,  max force (N)
K_w_info = np.array([[stiffnessSoil, forceSoil], ['0', 100]])
#  Initial greenfield displacement, step increase
u_gf = np.array([-0.002, -0.002, -0.1])
# Design multiplier mode
# MEP = 'true'


# Modes---------------------------------------------------
analysisMode = 'static'  # static
# selfWeight = 'true'  # Include self weight in calculation
selfWeight = 'false'  # Include self weight in calculation
showFigures = 'true'  # Display figures?
showFD      = 'false'  # SHow force, displacement curve
showForces = 'true'
showReactions = 'false'
plotMoments = 'false'  # Want moments in plots??
showPlasticBehaviour = 0  # 0 means only linear, 1 or higher is number of plastic steps
stressStiffening = 'false'    # yes or no. If included, runtime must be clicked twice to generate files and load loads
resetStress      = 'true'     # All stresses will be reset, This should be turned off for the 2nd run such that the initial stress file is loaded

# stressStiffening = 'true'    # yes or no. If included, runtime must be clicked twice to generate files and load loads
# resetStress      = 'false'     # All stresses will be reset, This should be turned off for the 2nd run such that the initial stress file is loaded

# Modifiers ----------------------------------------------
displacementScale = 10**(0)  # Default, 1m displacement is 1m in figure
forceScale = (0)  # Default is 0, so it is in kN, size of force vectors
#                  Global, N, Q, M
intForceScale = np.array([(0), 1.0 * 10 ** (0), 1.0 * 10 ** (0), 1.0 * 10 ** (0)])  # Default, size of internal forces
numElemPoints = 9  # Standard

# Indexing into structure to access later
scales = {"displacementScale": displacementScale, "forceScale": forceScale, "intForceScale": intForceScale,
          "numElemPoints": numElemPoints}
