import cupy as cp
import cupyx

# INPUT SCRIPT for 2D continuum FEA program by Sebastian V. Rosleff, B.Sc.

# Input file for 2D continuum mechanics analysis
nodeCoor = cp.array([[0, 0], [1, 0], [2, 0], [2, 0.5], [1, 0.5], [0, 0.5], [3, 0], [3, 0.5],  # 7
                     [2, 1], [1, 1], [0, 1], [3, 1]])  # Nodal coordinates
elemVec = cp.array([[0, 1, 4, 5], [1, 2, 3, 4], [2, 6, 7, 3], [3, 7, 11, 8],
                    [4, 3, 8, 9], [5, 4, 9, 10]])  # Element vectors
# nodeCoor = np.array([[0, 0], [1, 0], [2, 0], [2, 1], [1, 1], [0, 1], [3, 0], [3, 1]])  # Nodal coordinates
# elemVec = np.array([[0, 1, 4, 5], [1, 2, 3, 4], [2, 6, 7, 3]])  # Element vectors

E = cp.array([210 * 10 ** 9])  # [N/m^2]
gamma = cp.array([79500])  # [N/m^3]
nu = cp.array([0.3])  # [-]
t = cp.array([0.2])  # [m] Thickness
alpha = cp.array([12 * 10 ** (-5)])  # [1/K] Thermal expansion coefficient
G = cp.array([E[0] / (2 + 2 * nu[0])])  # [N/m^2]

# Material parameters
mat_par = cp.ones((len(elemVec))) * 0  # All the elements are of type 0

# Displacement        BD. node, DOF, imposed displacement
dispBound = cp.array([[0, 0, 0], [0, 1, 0], [10, 0, 0], [10, 1, 0], [5, 0, 0], [5, 1, 0]])
# dispBound = np.array([[0, 0, 0], [0, 1, 0], [5, 0, 0], [5, 1, 0]])

# Forces         Node , DOF, Magnitude  (Apply in N)
forces = cp.array([[11, 0, 1 * 10 ** 0]])

# Thermal loading (0 is reference temperature)
T_nodes = cp.ones((len(nodeCoor))) * 0

# Standardised springs Node, DOF, stiffness
springs = cp.array([[2, 1, 0.0 * 10 ** 0], [2, 1, 0.0 * 10 ** 0]])

# Element integration scheme
# (Reduced int, 1 order (weak form galerkin) [0] or fully integrated, 1 order elements (weak form galerkin) [1])
elemInt = cp.ones([len(elemVec), 1], int) * 0

# Element Stress state:
# 2D plane stress [0], 2D plane strain [1] (NOT IMPLEMENTED YET)
elemStressType = cp.ones([len(elemVec), 1], int) * 0

# Element type:
# Quadrilateral Q4 [0], Triangular Q3 (only fully int) [1]
elemType = cp.ones([len(elemVec), 1], int) * 0

# TRIANGULAR ELEMENT IS BROKEN IN VERSION 1 of GPU PROGRAM. .get() error in stiffness matrix



# Self-weight added
selfWeight = 'true'  # If true, self weight is included

# Only static ATM
# Dense means full matrix with all zeros, SPARCE uses SCIPY SPARCE instead.
analysisMode = 'staticSPARCE'  # staticDENSE
# analysisMode = 'staticDENSE'  # staticDENSE
dispScale = 10 ** (3)  # Displacement scale, default 1000 so unit is mm, also in deformation plot
plotSigma = 'true'  # true, false Can only plot rectangles as heat maps
plotTau   = 'true'
