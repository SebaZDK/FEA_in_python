import math
import numpy as np
import scipy as sci
# FUNCTION SCRIPT for 2D continuum FEA program by Sebastian V. Rosleff, B.Sc.
import sys


def magnitude(vector):
    return math.sqrt(sum(pow(element, 2) for element in vector))


def getDOF(boundarycondition, i, globalDOF):
    nodeBC = boundarycondition[i, 0]  # Get the node we are looking at
    nodeDOF = boundarycondition[i, 1]  # Get the local DOF
    valDOF = boundarycondition[i, 2]  # Get the displacement value
    yy = globalDOF[int(nodeBC)][0]  # Get the array row + Unpack it from array of array, to type array
    DOF = yy[int(nodeDOF)]  # Get the global index for the local DOF
    return nodeBC, nodeDOF, valDOF, DOF


def area_q3_element(elementcoordinates):
    # Takes in argument irregular 4 sided polygon, returns the lower and upper areas of the inside triangles.
    # Total area is found by summing A1 and A2
    S1 = magnitude(elementcoordinates[1, :] - elementcoordinates[0, :])  # Distance in m
    S2 = magnitude(elementcoordinates[2, :] - elementcoordinates[1, :])
    S3 = magnitude(elementcoordinates[0, :] - elementcoordinates[2, :])
    p1 = (S1 + S2 + S3) / 2  # Half the circumference of a triangle
    A1 = np.sqrt(p1 * (p1 - S1) * (p1 - S2) * (p1 - S3))  # Herons formula for area of triangle 1
    return A1


def area_q4_element(elementcoordinates):
    # Takes in argument irregular 4 sided polygon, returns the lower and upper areas of the inside triangles.
    # Total area is found by summing A1 and A2
    S1 = magnitude(elementcoordinates[1, :] - elementcoordinates[0, :])  # Distance in m
    S2 = magnitude(elementcoordinates[2, :] - elementcoordinates[1, :])
    S3 = magnitude(elementcoordinates[3, :] - elementcoordinates[2, :])
    S4 = magnitude(elementcoordinates[3, :] - elementcoordinates[0, :])
    Hyp = magnitude(elementcoordinates[2, :] - elementcoordinates[0, :])
    p1 = (S1 + S2 + Hyp) / 2  # Half the circumference of a triangle
    p2 = (S3 + S4 + Hyp) / 2
    A1 = np.sqrt(p1 * (p1 - S1) * (p1 - S2) * (p1 - Hyp))  # Herons formula for area of triangle 1
    A2 = np.sqrt(p2 * (p2 - S3) * (p2 - S4) * (p2 - Hyp))
    return A1, A2


def iso_4n_reduced(elementcoordinates, elasticmodulus, poissonratio, alpha, thickness, shearmodulus, qx, qy, q_self,
                   t_elem):
    # Area1 and Area2 are defined as small triangles within the Q4 element, such that self weight is calculated
    D_shear = 0
    k_elem = np.zeros([8, 8])
    f_c = np.zeros([8, 1])
    f_T = np.zeros([8, 1])

    # Gauss points and weight, lets not compute to save resources
    s = np.array([1 / np.sqrt(3), - 1 / np.sqrt(3)])
    w = np.array([1, 1])

    order = len(s)
    for i in range(order):
        for j in range(order):
            ds = dphi_ds(s[j])
            dt = dphi_dt(s[i])
            J = np.vstack([ds, dt]) @ elementcoordinates  # Jacobian of the coordinate transformation

            N = np.zeros([2, 8])  # Nodal displacement interpolation matrix
            N[0, [0, 2, 4, 6]] = dphi(s[i], s[j])
            N[1, [1, 3, 5, 7]] = dphi(s[i], s[j])

            # Consistent nodal load vector
            CNLV = N.reshape([8, 2]) @ np.array([[qx], [qy]]) * np.linalg.det(J) * w[i] * w[j]
            f_c[[0, 2, 4, 6]] += CNLV[[0, 1, 2, 3]]
            f_c[[1, 3, 5, 7]] += CNLV[[4, 5, 6, 7]]  # Python gives [u,u,u,u,v,v,v,v] we want [u,v,u,v,u,v,u,v]
            f_c[[1, 3, 5, 7]] += q_self.reshape(4, 1)  # Adding the load from self weight which has been calculated

            Bs = np.zeros([4, 8])  # Matrix containing diff. shape-functions u
            Bs[0, [0, 2, 4, 6]] = ds
            Bs[1, [0, 2, 4, 6]] = dt  # From earlier (dphi / dt)
            Bs[2, [1, 3, 5, 7]] = ds
            Bs[3, [1, 3, 5, 7]] = dt  #

            B_TEMP = np.array([[1, 0, 0, 0], [0, 0, 0, 1]])
            # blockJ = np.zeros([4, 4])
            # blockJ[np.ix_([0, 1], [0, 1])] = J
            # blockJ[np.ix_([2, 3], [2, 3])] = J
            blockJ = sci.linalg.block_diag(J, J)  # Does the same as above lines, but is coded in C# so faster...
            B = B_TEMP @ (np.linalg.solve(blockJ, Bs))

            # Implement the constitutive model for an isotropic, linear elastic material
            D = (elasticmodulus / (1 - poissonratio ** 2)) * np.array([[1, poissonratio, 0], [poissonratio, 1, 0],
                                                                       [0, 0, 0.5 * (1 - poissonratio)]])
            Q = -elasticmodulus * alpha / (1 - poissonratio) * np.array([[1], [1], [0]])
            # As the iso-parametric element used here is reduced order element referring to shear strain,
            # Only the E,xx and E,yy are used with full order integration. Therefore, the D matrix becomes:
            D_normal_strain = D[np.ix_([0, 1], [0, 1])]
            Q_normal_strain = Q[[0, 1]]
            # For shear contribution later:
            D_shear = np.array([D[2, 2]])

            # Constrict stiffness matrix
            k_elem += thickness * np.transpose(B) @ D_normal_strain @ B * np.linalg.det(J) * w[i] * w[j]
            # Thermal force vector
            f_T += (- thickness * np.transpose(B) @ Q_normal_strain *
                    dphi(s[i], s[j]) @ t_elem.reshape(4, 1) * np.linalg.det(J) * w[i] * w[j])
    # Gauss - points for reduced order integration for shear contribution
    s = np.array([0])
    w = np.array([2])

    ds = dphi_ds(s[0])
    dt = dphi_dt(s[0])
    J = np.vstack([ds, dt]) @ elementcoordinates  # Jacobian of the coordinate transformation

    Bs = np.zeros([4, 8])  # Matrix containing diff. shape-functions u
    Bs[0, [0, 2, 4, 6]] = ds
    Bs[1, [0, 2, 4, 6]] = dt  # From earlier (dphi / dt)
    Bs[2, [1, 3, 5, 7]] = ds
    Bs[3, [1, 3, 5, 7]] = dt  #

    B_TEMP = np.array([0, 1, 1, 0])
    # blockJ = np.zeros([4, 4])
    # blockJ[np.ix_([0, 1], [0, 1])] = J
    # blockJ[np.ix_([2, 3], [2, 3])] = J
    blockJ = sci.linalg.block_diag(J, J)  # Does the same as above lines, but is coded in C# so faster...
    B = np.array([B_TEMP @ (np.linalg.solve(blockJ, Bs))])
    k_elem += thickness * np.transpose(B).reshape(8, 1) * D_shear @ B * np.linalg.det(J) * w * w

    return k_elem, f_c, f_T


def iso_fe_4n_reduced(elementcoordinates, elasticmodulus, poissonratio, alpha, thickness, shearmodulus, disp_elem):
    D_shear = 0
    sigma1 = np.array([[0], [0]])
    sigma2 = np.array([[0], [0]])
    sigma3 = np.array([[0], [0]])
    sigma4 = np.array([[0], [0]])
    epsilon1 = np.array([[0], [0]])
    epsilon2 = np.array([[0], [0]])
    epsilon3 = np.array([[0], [0]])
    epsilon4 = np.array([[0], [0]])

    # Gauss points and weight, lets not compute to save resources
    s = np.array([1 / np.sqrt(3), - 1 / np.sqrt(3)])
    w = np.array([1, 1])

    order = len(s)
    for i in range(order):
        for j in range(order):
            ds = dphi_ds(s[j])
            dt = dphi_dt(s[i])
            J = np.vstack([ds, dt]) @ elementcoordinates  # Jacobian of the coordinate transformation

            N = np.zeros([2, 8])  # Nodal displacement interpolation matrix
            N[0, [0, 2, 4, 6]] = dphi(s[i], s[j])
            N[1, [1, 3, 5, 7]] = dphi(s[i], s[j])

            Bs = np.zeros([4, 8])  # Matrix containing diff. shape-functions u
            Bs[0, [0, 2, 4, 6]] = ds
            Bs[1, [0, 2, 4, 6]] = dt  # From earlier (dphi / dt)
            Bs[2, [1, 3, 5, 7]] = ds
            Bs[3, [1, 3, 5, 7]] = dt  #

            B_TEMP = np.array([[1, 0, 0, 0], [0, 0, 0, 1]])
            blockJ = sci.linalg.block_diag(J, J)  # Does the same as above lines, but is coded in C# so faster...
            B = B_TEMP @ (np.linalg.solve(blockJ, Bs))

            # Implement the constitutive model for an isotropic, linear elastic material
            D = (elasticmodulus / (1 - poissonratio ** 2)) * np.array([[1, poissonratio, 0], [poissonratio, 1, 0],
                                                                       [0, 0, 0.5 * (1 - poissonratio)]])
            Q = elasticmodulus * alpha / (1 - poissonratio) * np.array([[1], [1], [0]])
            # As the iso-parametric element used here is reduced order element referring to shear strain,
            # Only the E,xx and E,yy are used with full order integration. Therefore, the D matrix becomes:
            D_normal_strain = D[np.ix_([0, 1], [0, 1])]

            # For shear contribution later:
            D_shear = np.array([D[2, 2]])

            # Determine stresses and strains
            if i == 0 and j == 0:
                epsilon1 = B @ disp_elem
                sigma1 = D_normal_strain @ B @ disp_elem
            elif i == 0 and j == 1:
                epsilon2 = B @ disp_elem
                sigma2 = D_normal_strain @ B @ disp_elem
            elif i == 1 and j == 0:
                epsilon3 = B @ disp_elem
                sigma3 = D_normal_strain @ B @ disp_elem
            elif i == 1 and j == 1:
                epsilon4 = B @ disp_elem
                sigma4 = D_normal_strain @ B @ disp_elem
            # epsilon[i, j] = B @ disp_elem
    # Gauss - points for reduced order integration for shear contribution
    s = np.array([0])
    w = np.array([2])

    ds = dphi_ds(s[0])
    dt = dphi_dt(s[0])
    J = np.vstack([ds, dt]) @ elementcoordinates  # Jacobian of the coordinate transformation

    Bs = np.zeros([4, 8])  # Matrix containing diff. shape-functions u
    Bs[0, [0, 2, 4, 6]] = ds
    Bs[1, [0, 2, 4, 6]] = dt  # From earlier (dphi / dt)
    Bs[2, [1, 3, 5, 7]] = ds
    Bs[3, [1, 3, 5, 7]] = dt  #

    B_TEMP = np.array([0, 1, 1, 0])
    blockJ = sci.linalg.block_diag(J, J)  # Does the same as above lines, but is coded in C# so faster...
    B = np.array([B_TEMP @ (np.linalg.solve(blockJ, Bs))])
    tau = D_shear * B @ disp_elem
    gamma = B @ disp_elem

    sigma = np.hstack([sigma1, sigma2, sigma3, sigma4])
    epsilon = np.hstack([epsilon1, epsilon2, epsilon3, epsilon4])
    return sigma, epsilon, tau, gamma


def iso_4n_full(elementcoordinates, elasticmodulus, poissonratio, alpha, thickness, shearmodulus, qx, qy, q_self,
                t_elem):
    # Area1 and Area2 are defined as small triangles within the Q4 element, such that self weight is calculated
    D_shear = 0
    k_elem = np.zeros([8, 8])
    f_c = np.zeros([8, 1])
    f_T = np.zeros([8, 1])

    # Gauss points and weight, lets not compute to save resources
    s = np.array([1 / np.sqrt(3), - 1 / np.sqrt(3)])
    w = np.array([1, 1])

    order = len(s)
    for i in range(order):
        for j in range(order):
            ds = dphi_ds(s[j])
            dt = dphi_dt(s[i])
            J = np.vstack([ds, dt]) @ elementcoordinates  # Jacobian of the coordinate transformation

            N = np.zeros([2, 8])  # Nodal displacement interpolation matrix
            N[0, [0, 2, 4, 6]] = dphi(s[i], s[j])
            N[1, [1, 3, 5, 7]] = dphi(s[i], s[j])

            # Consistent nodal load vector
            CNLV = N.reshape([8, 2]) @ np.array([[qx], [qy]]) * np.linalg.det(J) * w[i] * w[j]
            f_c[[0, 2, 4, 6]] += CNLV[[0, 1, 2, 3]]
            f_c[[1, 3, 5, 7]] += CNLV[[4, 5, 6, 7]]  # Python gives [u,u,u,u,v,v,v,v] we want [u,v,u,v,u,v,u,v]
            f_c[[1, 3, 5, 7]] += q_self.reshape(4, 1)  # Adding the load from self weight which has been calculated

            Bs = np.zeros([4, 8])  # Matrix containing diff. shape-functions u
            Bs[0, [0, 2, 4, 6]] = ds
            Bs[1, [0, 2, 4, 6]] = dt  # From earlier (dphi / dt)
            Bs[2, [1, 3, 5, 7]] = ds
            Bs[3, [1, 3, 5, 7]] = dt  #

            B_TEMP = np.array([[1, 0, 0, 0], [0, 0, 0, 1], [0, 1, 1, 0]])
            # blockJ = np.zeros([4, 4])
            # blockJ[np.ix_([0, 1], [0, 1])] = J
            # blockJ[np.ix_([2, 3], [2, 3])] = J
            blockJ = sci.linalg.block_diag(J, J)  # Does the same as above lines, but is coded in C# so faster...
            B = B_TEMP @ (np.linalg.solve(blockJ, Bs))

            # Implement the constitutive model for an isotropic, linear elastic material
            D = (elasticmodulus / (1 - poissonratio ** 2)) * np.array([[1, poissonratio, 0], [poissonratio, 1, 0],
                                                                       [0, 0, 0.5 * (1 - poissonratio)]])
            Q = -elasticmodulus * alpha / (1 - poissonratio) * np.array([[1], [1], [0]])

            # Construct stiffness matrix
            k_elem += thickness * np.transpose(B) @ D @ B * np.linalg.det(J) * w[i] * w[j]
            # Thermal force vector
            f_T += (- thickness * np.transpose(B) @ Q *
                    dphi(s[i], s[j]) @ t_elem.reshape(4, 1) * np.linalg.det(J) * w[i] * w[j])
            print(dphi(s[i], s[j]) @ t_elem.reshape(4, 1))

    return k_elem, f_c, f_T


def iso_fe_4n_full(elementcoordinates, elasticmodulus, poissonratio, alpha, thickness, shearmodulus, disp_elem):
    D_shear = 0
    sigma1 = np.array([[0], [0], [0]])
    sigma2 = np.array([[0], [0], [0]])
    sigma3 = np.array([[0], [0], [0]])
    sigma4 = np.array([[0], [0], [0]])
    epsilon1 = np.array([[0], [0], [0]])
    epsilon2 = np.array([[0], [0], [0]])
    epsilon3 = np.array([[0], [0], [0]])
    epsilon4 = np.array([[0], [0], [0]])

    # Gauss points and weight, lets not compute to save resources
    s = np.array([1 / np.sqrt(3), - 1 / np.sqrt(3)])
    w = np.array([1, 1])

    order = len(s)
    for i in range(order):
        for j in range(order):
            ds = dphi_ds(s[j])
            dt = dphi_dt(s[i])
            J = np.vstack([ds, dt]) @ elementcoordinates  # Jacobian of the coordinate transformation

            N = np.zeros([2, 8])  # Nodal displacement interpolation matrix
            N[0, [0, 2, 4, 6]] = dphi(s[i], s[j])
            N[1, [1, 3, 5, 7]] = dphi(s[i], s[j])

            Bs = np.zeros([4, 8])  # Matrix containing diff. shape-functions u
            Bs[0, [0, 2, 4, 6]] = ds
            Bs[1, [0, 2, 4, 6]] = dt  # From earlier (dphi / dt)
            Bs[2, [1, 3, 5, 7]] = ds
            Bs[3, [1, 3, 5, 7]] = dt  #

            B_TEMP = np.array([[1, 0, 0, 0], [0, 0, 0, 1], [0, 1, 1, 0]])
            blockJ = sci.linalg.block_diag(J, J)  # Does the same as above lines, but is coded in C# so faster...
            B = B_TEMP @ (np.linalg.solve(blockJ, Bs))

            # Implement the constitutive model for an isotropic, linear elastic material
            D = (elasticmodulus / (1 - poissonratio ** 2)) * np.array([[1, poissonratio, 0], [poissonratio, 1, 0],
                                                                       [0, 0, 0.5 * (1 - poissonratio)]])
            Q = elasticmodulus * alpha / (1 - poissonratio) * np.array([[1], [1], [0]])

            # Determine stresses and strains
            if i == 0 and j == 0:
                epsilon1 = B @ disp_elem
                sigma1 = D @ B @ disp_elem
            elif i == 0 and j == 1:
                epsilon2 = B @ disp_elem
                sigma2 = D @ B @ disp_elem
            elif i == 1 and j == 0:
                epsilon3 = B @ disp_elem
                sigma3 = D @ B @ disp_elem
            elif i == 1 and j == 1:
                epsilon4 = B @ disp_elem
                sigma4 = D @ B @ disp_elem

    sigma = np.hstack([sigma1, sigma2, sigma3, sigma4])
    epsilon = np.hstack([epsilon1, epsilon2, epsilon3, epsilon4])
    return sigma, epsilon


def KufSolve(K, d, f, r, forceKnown, dispKnown, analysisMode):
    # Solve system of equations: ---------------------------------------------------------------------------------------
    f1 = forceKnown.T
    f1 = f1[0]  # Unpacking for python
    d1 = dispKnown.T
    d1 = d1[0]

    match analysisMode:
        case 'staticSPARCE':
            As = K[np.ix_(f1, f1)]  # A in A*x = B corresponds to K in K*u = f
            Bs = f[f1] - K[np.ix_(f1, d1)] @ d[d1]  # B in A*x = B corresponds to f in K*u = f
            solution = np.array([sci.sparse.linalg.spsolve(As, Bs, permc_spec=None)]).reshape(-1, 1)
            d[f1] = solution  # Determines u in K*u = f
            # THIS DOES NOT WORK WITH SPARCE MATRICES
            # Xs = d[f1]  # Defines a variable
            # answer = np.allclose(np.dot(As, Xs), Bs)  # Checking that the solution is correct to tolerance
            # print('Is the static solution correct?', answer)  # Writes out answer
        case 'staticDENSE':
            # THIS DOES NOT WORK WITH SPARCE MATRICES
            detK = np.linalg.det(K[np.ix_(f1, f1)])  # Help function ix_ allows for MATLAB like indexing
            if detK == 0:
                sys.exit('There is no stiffness in your system')
            elif detK < 0:
                sys.exit('There is negative stiffness in your system')
            As = K[np.ix_(f1, f1)]  # A in A*x = B corresponds to K in K*u = f
            Bs = f[f1] - K[np.ix_(f1, d1)] @ d[d1]  # B in A*x = B corresponds to f in K*u = f
            d[f1] = np.linalg.solve(As, Bs)  # Determines u in K*u = f
            Xs = d[f1]  # Defines a variable
            answer = np.allclose(np.dot(As, Xs), Bs)  # Checking that the solution is correct to tolerance
            print('Is the static solution correct?', answer)  # Writes out answer

    # Calculate reactions in supported nodes
    r[d1] = K[np.ix_(d1, d1)] @ d[d1] + K[np.ix_(d1, f1)] @ d[f1] - f[d1]

    return d, f, r


def dphi_ds(s):
    s2 = s / 4
    s3 = -s2
    return np.array([s2 - 1 / 4, s3 + 1 / 4, s2 + 1 / 4, s3 - 1 / 4])


def dphi_dt(t):
    t2 = t / 4
    t3 = -t2
    return np.array([t2 - 1 / 4, t3 - 1 / 4, t2 + 1 / 4, t3 + 1 / 4])


def dphi(s, t):
    s1 = s + 1
    t1 = t + 1
    s2 = s - 1
    t2 = t - 1
    return np.array([(s2 * t2) / 4, s1 * t2 * (-1 / 4), (s1 * t1) / 4, (t1 * s2) * (-1 / 4)])

def iso_3n_full(elementcoordinates, elasticmodulus, poissonratio, alpha, thickness, shearmodulus, qx, qy, q_self,
                t_elem):
    # Area1 and Area2 are defined as small triangles within the Q4 element, such that self weight is calculated
    D_shear = 0
    k_elem = np.zeros([6, 6])
    f_c = np.zeros([6, 1])
    f_T = np.zeros([6, 1])

    x = elementcoordinates[:, 0]
    y = elementcoordinates[:, 1]
    x13 = x[0] - x[2]
    x23 = x[1] - x[2]
    y13 = y[0] - y[2]
    y23 = y[1] - y[2]

    J = np.array([[x13, y13], [x23, y23]])  # Jacobian of the coordinate transformation

    # N = np.zeros([2, 6])  # Nodal displacement interpolation matrix
    # N[0, [0, 2, 4]] = dphi(s[i], s[j])
    # N[1, [1, 3, 5]] = dphi(s[i], s[j])

    # Consistent nodal load vector
    # CNLV = N.reshape([6, 2]) @ np.array([[qx], [qy]]) * np.linalg.det(J) * w[i] * w[j]
    # f_c[[0, 2, 4]] += CNLV[[0, 1, 2]]
    # f_c[[1, 3, 5]] += CNLV[[4, 5, 6]]  # Python gives [u,u,u,u,v,v,v,v] we want [u,v,u,v,u,v,u,v]
    f_c[[1, 3, 5]] += q_self.reshape(3, 1)  # Adding the load from self weight which has been calculated

    B = (1 / np.linalg.det(J)) * np.array([[y23, 0, y[2] - y[0], 0, y[0] - y[1], 0],
                                           [0, x[2] - x[1], 0, x13, 0, x[1] - x[0]],
                                           [x[2] - x[1], y23, x13, y[2] - y[0], x[1] - x[0], y[0] - y[1]]])

    # Implement the constitutive model for an isotropic, linear elastic material
    D = (elasticmodulus / (1 - poissonratio ** 2)) * np.array([[1, poissonratio, 0], [poissonratio, 1, 0],
                                                                       [0, 0, 0.5 * (1 - poissonratio)]])
    Q = -elasticmodulus * alpha / (1 - poissonratio) * np.array([[1], [1], [0]])

    # Construct stiffness matrix
    k_elem += thickness * 0.5 * np.linalg.det(J) * np.transpose(B) @ D @ B
    print(np.transpose(B) @ D @ B)
    # f_T += (- thickness * np.transpose(B) @ Q * t_elem.reshape(3, 1) * np.linalg.det(J))

    return k_elem, f_c, f_T

def iso_fe_3n_full(elementcoordinates, elasticmodulus, poissonratio, alpha, thickness, shearmodulus, disp_elem):
    k_elem = np.zeros([6, 6])

    x = elementcoordinates[:, 0]
    y = elementcoordinates[:, 1]
    x13 = x[0] - x[2]
    x23 = x[1] - x[2]
    y13 = y[0] - y[2]
    y23 = y[1] - y[2]

    J = np.array([[x13, y13], [x23, y23]])  # Jacobian of the coordinate transformation

    B = (1 / np.linalg.det(J)) * np.array([[y23, 0, y[2] - y[0], 0, y[0] - y[1], 0],
                                           [0, x[2] - x[1], 0, x13, 0, x[1] - x[0]],
                                           [x[2] - x[1], y23, x13, y[2] - y[0], x[1] - x[0], y[0] - y[1]]])

    # Implement the constitutive model for an isotropic, linear elastic material
    D = (elasticmodulus / (1 - poissonratio ** 2)) * np.array([[1, poissonratio, 0], [poissonratio, 1, 0],
                                                                       [0, 0, 0.5 * (1 - poissonratio)]])

    # Construct stiffness matrix
    k_elem += thickness * 0.5 * np.linalg.det(J) * np.transpose(B) @ D @ B

    sigma = D @ B @ disp_elem
    epsilon = B @ disp_elem
    return sigma, epsilon

