# MAIN SCRIPT for 2D continuum FEA program by Sebastian V. Rosleff, B.Sc.
import plotly.graph_objects as go
import timeit  # To time programs

tic = timeit.default_timer()  # Used to elapse time

# Import files
from Geometry_2D import *  # Import geometry
from StiffnessFunctions2D_ISO import *  # Import functions

# Initialize
DofPerNodes = 2
numElem = len(elemVec)
numNodes = len(nodeCoor)
numGlobalDOF = numNodes * DofPerNodes  # Number of total DOF's
numMat = len(mat_par)  # Number of materials

if "dispBound" in globals():
    numDispBound = len(dispBound)  # Number of displacement boundary conditions
else:
    numDispBound = 0
if "forces" in globals():
    numForceBound = len(forces)  # Number of force imposed on structure
else:
    numForceBound = 0
numNodalDOF = np.ones((numNodes, 1)) * DofPerNodes  # Every node has 2 DOF's in 2D here

# Get the global DOF for each node:
globalDOF = np.empty([numNodes], dtype=object)  # Create an empty array of arrays
globalDOF = np.reshape(globalDOF, (numNodes, 1))  # Reshape it to be a column vector (Python does not know this)
globalDOF3 = np.zeros([numNodes, 3])  # Used later for data storage
dofEnd = 0  # Create a starting value
for i in range(numNodes):  # Over all nodes from 0 to end
    if i == 0:
        dofStart = dofEnd  # Starting node
        dof6 = dofEnd + 3  # Last node in rearranged output
    else:
        dofStart = dofEnd  # Starting node
        dof6 = dofEnd + 3  # Last node in rearranged output
    dofEnd += int(numNodalDOF[i])  # True last DOF for the specific node
    globalDOF[i, 0] = np.asarray(list(range(dofStart, dofEnd)))  # The global DOF numbers not arranged
    globalDOF3[i, :] = np.asarray(list(range(dofStart, dof6)))  # The global DOF arranged
globalDOF3 = np.reshape(globalDOF3, (globalDOF3.size, 1))  # Reshaping to a list for later use

elemGlobalDOF = np.zeros([numElem, 4 * DofPerNodes])  # Create matrix for storing DOF's later
for i in range(numElem):  # For every element
    elemNodes = elemVec[i, :]  # Get the nodes
    ktemp1 = globalDOF[elemNodes[0], :][0]  # Retrieve the array of the array globalDOF
    ktemp2 = globalDOF[elemNodes[1], :][0]
    ktemp3 = globalDOF[elemNodes[2], :][0]  # Retrieve the array and unpack array of arrays
    ktemp4 = globalDOF[elemNodes[3], :][0]
    # Index into the elemGlobalDOF, every node DOF (u,v) i
    elemGlobalDOF[i, np.asarray(list(range(DofPerNodes)))] = ktemp1[np.asarray(list(range(DofPerNodes)))]
    elemGlobalDOF[i, np.asarray(list(range(DofPerNodes, 2 * DofPerNodes)))] = ktemp2[
        np.asarray(list(range(DofPerNodes)))]
    elemGlobalDOF[i, np.asarray(list(range(2 * DofPerNodes, 3 * DofPerNodes)))] = ktemp3[
        np.asarray(list(range(DofPerNodes)))]
    elemGlobalDOF[i, np.asarray(list(range(3 * DofPerNodes, 4 * DofPerNodes)))] = ktemp4[
        np.asarray(list(range(DofPerNodes)))]

# Assemble system of equations for the matrices------------------------------------
tempK = np.zeros((numGlobalDOF, numGlobalDOF))  # Create temporary stiffness matrix
# K = tempK.copy()  # Cannot calculate det(K) in python for sparce
match analysisMode:
    case 'staticSPARCE':
        K = sci.sparse.lil_matrix(tempK.copy())  # Convert it to sparce matrix to same memory
        KSpring = sci.sparse.lil_matrix(tempK.copy())  # Stiffness matrix for springs
    case 'staticDENSE':
        K = tempK.copy()  #
        KSpring = tempK.copy()  # Stiffness matrix for springs
f = np.zeros([numGlobalDOF, 1])  # Force vector for output
ft = np.zeros([numGlobalDOF, 1])  # Thermal force vector for output
d = np.zeros([numGlobalDOF, 1])  # Displacement vector for output
r = np.zeros([numGlobalDOF, 1])  # Reaction vector for output
# dispVec = np.zeros([numGlobalDOF, 1])  # Displacement vector
elemForce = np.zeros([numElem, 4])  # Element force vector
elemStrain = np.zeros([numElem, 4])  # Element strain vector

# Make boolean vectors
dispKnown = np.zeros([numGlobalDOF, 1], dtype=bool)  # All displacements are unknown
forceKnown = np.ones([numGlobalDOF, 1], dtype=bool)  # All forces are known

# Implement boundary conditions ;)---------------------------------------------------
for i in range(numDispBound):  # For all boundary conditions
    [nodeBC, nodeDOF, valDOF, DOF] = getDOF(dispBound, i, globalDOF)
    dispKnown[DOF] = not dispKnown[DOF]  # Switch the bool to true
    forceKnown[DOF] = not forceKnown[DOF]  # Switch the bool to false
    d[DOF] = valDOF  # Assign known displacement to displacement vector

# Also some forces are known, these will be implemented now:
for i in range(numForceBound):
    [nodeBC, nodeDOF, valDOF, DOF] = getDOF(forces, i, globalDOF)
    f[DOF] = valDOF  # No boolean switch required, first assumption == true

# Linear springs
if 'springs' in globals() and len(springs) != 0:
    numSprings = int(springs.shape[0])
else:
    numSprings = 0

for i in range(numSprings):  # For all spring boundary conditions
    [nodeBC, nodeDOF, valStiff, DOF] = getDOF(springs, i, globalDOF)
    KSpring[DOF, DOF] += valStiff  # Index the stiffness into that diagonal

# Assemble matrices
for i in range(numElem):
    match elemType[i]:
        case 0:  # Case Q4 element
            elemNodes = elemVec[i, :]  # Load all element nodes
            elemDOF = elemGlobalDOF[i, :].astype(int)  # Load all DOF's
            elemCoor = nodeCoor[elemNodes, :]  # Get all coordinates
            mat = int(mat_par[i])
            T_elem = T_nodes[elemNodes]

            if 'gamma' in globals() and selfWeight == 'true':
                [A1, A2] = area_q4_element(
                    elemCoor)  # Get area of lower and upper internal triangles from Heron's formula
                qx = 0  # To be implemented later
                qy = 0
                q_self = -np.array([(A1 + A2) / 4, A1 / 2, (A1 + A2) / 4, A2 / 2]) * t * gamma[mat]  # Self weight
            else:
                qx = 0  # To be implemented later
                qy = 0
                q_self = np.zeros([4, 1])

            # Use function to determine local stiffness matrix, nodal load vector and thermal force
            if elemInt[i] == 0:  # Use reduced order integration scheme on 1 order element (Constant shear)
                [k_Local, f_c, f_T] = iso_4n_reduced(elemCoor, E[mat], nu[mat], alpha[mat], t, G[mat], qx, qy, q_self,
                                                     T_elem)
            elif elemInt[i] == 1:  # Use full integration scheme on 1 order element (Risk of Shear locking)
                [k_Local, f_c, f_T] = iso_4n_full(elemCoor, E[mat], nu[mat], alpha[mat], t, G[mat], qx, qy, q_self,
                                                  T_elem)
            K[np.ix_(elemDOF, elemDOF)] += k_Local
            f[elemDOF] += f_c  # Adding forces
            ft[elemDOF] += f_T  # Adding thermal forces

        case 1:  # Case triangular element
            elemNodes = elemVec[i, [0, 1, 2]]  # Load all element nodes
            elemDOF = elemGlobalDOF[i, [0, 1, 2, 3, 4, 5]].astype(int)  # Load all DOF's
            elemCoor = nodeCoor[elemNodes, :]  # Get all coordinates
            mat = int(mat_par[i])
            T_elem = T_nodes[elemNodes]

            if 'gamma' in globals() and selfWeight == 'true':
                A1 = area_q3_element(elemCoor)  # Get area of lower and upper internal triangles from Heron's formula
                qx = 0  # To be implemented later
                qy = 0
                q_self = -np.array([A1 / 3, A1 / 3, A1 / 3]) * t * gamma[mat]  # Self weight
            else:
                qx = 0  # To be implemented later
                qy = 0
                q_self = np.zeros([3, 1])

            # Use function to determine local stiffness matrix, nodal load vector and thermal force
            [k_Local, f_c, f_T] = iso_3n_full(elemCoor, E[mat], nu[mat], alpha[mat], t, G[mat], qx, qy, q_self,
                                              T_elem)
            print(np.ix_(elemDOF, elemDOF))
            K[np.ix_(elemDOF, elemDOF)] += k_Local
            f[elemDOF] += f_c  # Adding forces
            ft[elemDOF] += f_T  # Adding thermal forces

# Add stiffness matrices
K += KSpring
f += ft

# Compute solution using sparce matrices
ticK = timeit.default_timer()  # Measure time for solving the stiffness matrix
if analysisMode == 'staticSPARCE' or analysisMode == 'staticDENSE':
    [d, f, r] = KufSolve(K, d, f, r, forceKnown, dispKnown, analysisMode)
tocK = timeit.default_timer()

# To compute force in the elastic springs, the matrix needs to be dense, as the sparce solver returns NAN always
if analysisMode == 'staticSPARCE':
    KSpring.todense()
    print('Using sparce matrices')
elif analysisMode == 'staticDENSE':
    print('Using dense matrices, may be expensive computationally for large systems')
f_springs = KSpring @ d  # Compute spring forces
# print(d, 'Displacements (m)', f, 'forces (N)', r, 'Reactions (N)', f_springs, 'Force in elastic springs (N)')

# Arrays to store stresses in
elem_sigma_xx = np.zeros([numElem, 4])
elem_sigma_yy = np.zeros([numElem, 4])
elem_eps_xx = np.zeros([numElem, 4])
elem_eps_yy = np.zeros([numElem, 4])
elem_tau_p = np.zeros([numElem, 4])
elem_gamma_p = np.zeros([numElem, 4])

# Compute internal forces
for i in range(numElem):
    match elemType[i]:
        case 0:  # Case Q4 element
            elemNodes = elemVec[i, :]  # Load all element nodes
            elemDOF = elemGlobalDOF[i, :].astype(int)  # Load all DOF's
            elemCoor = nodeCoor[elemNodes, :]  # Get all coordinates
            d_elem = d[elemDOF]  # Retrieve displacement at elemDOF
            # print(d_elem)
            if elemInt[i] == 0:  # Reduced order integration scheme:
                [elem_sigma, elem_eps, elem_tau, elem_gamma] = iso_fe_4n_reduced(elemCoor, E[mat], nu[mat], alpha[mat],
                                                                                 t,
                                                                                 G[mat], d_elem)
                elem_sigma_xx[i, :] = elem_sigma[0, :]  # Extracting stresses
                elem_sigma_yy[i, :] = elem_sigma[1, :]
                elem_eps_xx[i, :] = elem_eps[0, :]
                elem_eps_yy[i, :] = elem_eps[1, :]
                elem_tau_p[i, 0] = elem_tau[0][0]  # Unpacking of array(array) to float to index into array
                elem_gamma_p[i, 0] = elem_gamma[0][0]
            if elemInt[i] == 1:  # Reduced order integration scheme:
                [elem_sigma, elem_eps] = iso_fe_4n_full(elemCoor, E[mat], nu[mat], alpha[mat], t, G[mat], d_elem)
                elem_sigma_xx[i, :] = elem_sigma[0, :]  # Extracting stresses
                elem_sigma_yy[i, :] = elem_sigma[1, :]
                elem_eps_xx[i, :] = elem_eps[0, :]
                elem_eps_yy[i, :] = elem_eps[1, :]
                elem_tau_p[i, :] = elem_sigma[2, :]
                elem_gamma_p[i, :] = elem_eps[2, :]
        case 1:  # Case Q2 element
            elemNodes = elemVec[i, [0, 1, 2]]  # Load all element nodes
            elemDOF = elemGlobalDOF[i, [0, 1, 2, 3, 4, 5]].astype(int)  # Load all DOF's
            elemCoor = nodeCoor[elemNodes, :]  # Get all coordinates
            d_elem = d[elemDOF]
            [elem_sigma, elem_eps] = iso_fe_3n_full(elemCoor, E[mat], nu[mat], alpha[mat], t, G[mat], d_elem)
            elem_sigma_xx[i, [0, 1, 2]] = elem_sigma[0, :]  # Extracting stresses
            elem_sigma_yy[i, [0, 1, 2]] = elem_sigma[1, :]
            elem_eps_xx[i, [0, 1, 2]] = elem_eps[0, :]
            elem_eps_yy[i, [0, 1, 2]] = elem_eps[1, :]
            elem_tau_p[i, [0, 1, 2]] = elem_sigma[2, :]
            elem_gamma_p[i, [0, 1, 2]] = elem_eps[2, :]

toc0 = timeit.default_timer()  # The execution time of the program itself

#
# Now all forces are known and extracted
# Reshape arrays to match nodeCoor
d = d.reshape(numNodes, 2)
f = f.reshape(numNodes, 2)
r = r.reshape(numNodes, 2)
xDisp1 = np.zeros(6 * numElem)  # Reset vectors for plotting
yDisp1 = np.zeros(6 * numElem)
xDispS = np.zeros(6 * numElem)  # Reset vectors for plotting the Standard / un-deformed 'original nodes'
yDispS = np.zeros(6 * numElem)
xDispO = nodeCoor[:, 0] + d[:, 0] * dispScale  # Creating the displacement nodes for plotting
yDispO = nodeCoor[:, 1] + d[:, 1] * dispScale
xDisp = xDispO.reshape(numNodes, 1)
yDisp = yDispO.reshape(numNodes, 1)
dispCoor = np.hstack([xDisp, yDisp])
for i in range(elemVec.shape[0]):  # For every element
    elemNodes = elemVec[i, :]  # Get the nodes
    coord = dispCoor[elemNodes]
    coordS = nodeCoor[elemNodes]
    # indexing all x plus , plus first node and an extra nan node
    xDisp1[6 * i:6 * i + 6] = np.hstack([coord[:, 0], coord[0, 0], np.nan])
    yDisp1[6 * i:6 * i + 6] = np.hstack([coord[:, 1], coord[0, 1], np.nan])
    xDispS[6 * i:6 * i + 6] = np.hstack([coordS[:, 0], coordS[0, 0], np.nan])
    yDispS[6 * i:6 * i + 6] = np.hstack([coordS[:, 1], coordS[0, 1], np.nan])

# PLOTTING ROUTINES -----------------------------------------------------------------------------------
# PLOTTING ROUTINES DEFORMATION PLOT

figDEF = go.Figure()
figDEF.add_trace(go.Scatter(x=xDispS, y=yDispS, name="Un-deformed elements",
                            mode="lines", fill="toself",
                            line=dict(color="Blue", width=2), ))  # Plot un-deformed nodes
figDEF.add_trace(go.Scatter(x=xDisp1, y=yDisp1, name="Deformed elements",
                            mode="lines", fill="toself",
                            line=dict(color="lightsalmon", width=2), ))  # Plot deformed nodes
[xMin, xMax, yMin, yMax] = [xDisp.min(), xDisp.max(), yDisp.min(), yDisp.max()]  # Get dataset boundaries
figDEF.update_xaxes(range=[xMin - 0.5, xMax + 0.5])
figDEF.update_yaxes(range=[yMin - 0.5, yMax + 0.5])
figDEF.update_layout(
    title=go.layout.Title(text="Deformation plot", xref="paper", x=0),
    xaxis=go.layout.XAxis(title=go.layout.xaxis.Title(text="x coordinate in [m]", font=dict(
        family="Courier New, monospace", size=18, color="#7f7f7f"))),
    yaxis=go.layout.YAxis(title=go.layout.yaxis.Title(text="y coordinate in [m]", font=dict(
        family="Courier New, monospace", size=18, color="#7f7f7f"))))
figDEF.show()

# PLOTTING ROUTINES -----------------------------------------------------------------------------------
# PLOTTING ROUTINES STRESS PLOTS
if plotSigma == 'true':
    figSigma_xx = go.Figure()
    figSigma_yy = go.Figure()
    [zmin_xx, zmax_xx] = [elem_sigma_xx.min() / 10 ** 6, elem_sigma_xx.max() / 10 ** 6]
    [zmin_yy, zmax_yy] = [elem_sigma_yy.min() / 10 ** 6, elem_sigma_yy.max() / 10 ** 6]
    for i in range(numElem):
        if elemType[i] == 0:
            elemNodes = elemVec[i, :]  # Get the nodes
            coordS = nodeCoor[elemNodes]
            xx = elem_sigma_xx[i, :] / 10 ** 6
            yy = elem_sigma_yy[i, :] / 10 ** 6
            figSigma_xx.add_trace(go.Contour(
                z=[[xx[3], xx[1]], [xx[2], xx[0]]],
                x=[coordS[0, 0], coordS[1, 0]],  # horizontal axis
                y=[coordS[0, 1], coordS[3, 1]],  # vertical axis
                zmin=zmin_xx, zmid=0, zmax=zmax_xx, contours=dict(coloring='heatmap'),
                colorbar=dict(title='sigma_xx [MPa]', titleside='right',
                              titlefont=dict(size=14, family='Arial, sans-serif'))))
            figSigma_yy.add_trace(go.Contour(
                # z=[[yy[0], yy[1]], [yy[3], yy[2]]],
                z=[[yy[2], yy[0]], [yy[3], yy[1]]],
                x=[coordS[0, 0], coordS[1, 0]],  # horizontal axis
                y=[coordS[0, 1], coordS[3, 1]],  # vertical axis
                zmin=zmin_yy, zmid=0, zmax=zmax_yy, contours=dict(coloring='heatmap'),
                colorbar=dict(title='sigma_yy [MPa] (Not accurate placement, only scale)', titleside='right',
                              titlefont=dict(size=14, family='Arial, sans-serif'))))
        elif elemType[i] == 1:
            elemNodes = elemVec[i, :]  # Get the nodes
            coordS = nodeCoor[elemNodes]
            coordS[3, :] = [coordS[1, 0], coordS[2, 1]]
            xx = elem_sigma_xx[i, :] / 10 ** 6
            yy = elem_sigma_yy[i, :] / 10 ** 6
            figSigma_xx.add_trace(go.Contour(
                z=[[xx[3], xx[1]], [xx[2], 0]],
                x=[coordS[0, 0], coordS[1, 0]],  # horizontal axis
                y=[coordS[0, 1], coordS[3, 1]],  # vertical axis
                zmin=zmin_xx, zmid=0, zmax=zmax_xx, contours=dict(coloring='heatmap'),
                colorbar=dict(title='sigma_xx [MPa]', titleside='right',
                              titlefont=dict(size=14, family='Arial, sans-serif'))))
            figSigma_yy.add_trace(go.Contour(
                # z=[[yy[0], yy[1]], [yy[3], yy[2]]],
                z=[[yy[2], yy[0]], [yy[3], yy[1]]],
                x=[coordS[0, 0], coordS[1, 0]],  # horizontal axis
                y=[coordS[0, 1], coordS[3, 1]],  # vertical axis
                zmin=zmin_yy, zmid=0, zmax=zmax_yy, contours=dict(coloring='heatmap'),
                colorbar=dict(title='sigma_yy [MPa] (Not accurate placement, only scale)', titleside='right',
                              titlefont=dict(size=14, family='Arial, sans-serif'))))
    figSigma_xx.update_layout(
        title=go.layout.Title(text="Sigma_xx in [MPa]", xref="paper", x=0),
        xaxis=go.layout.XAxis(title=go.layout.xaxis.Title(text="x coordinate in [m]", font=dict(
            family="Courier New, monospace", size=18, color="#7f7f7f"))),
        yaxis=go.layout.YAxis(title=go.layout.yaxis.Title(text="y coordinate in [m]", font=dict(
            family="Courier New, monospace", size=18, color="#7f7f7f"))))
    figSigma_xx.show()
    figSigma_yy.update_layout(
        title=go.layout.Title(text="Sigma_y in [MPa] (Inaccurate as coordinates are stupid)", xref="paper", x=0),
        xaxis=go.layout.XAxis(title=go.layout.xaxis.Title(text="x coordinate in [m]", font=dict(
            family="Courier New, monospace", size=18, color="#7f7f7f"))),
        yaxis=go.layout.YAxis(title=go.layout.yaxis.Title(text="y coordinate in [m]", font=dict(
            family="Courier New, monospace", size=18, color="#7f7f7f"))))
    figSigma_yy.show()  # I do not know how to plot yy stresses correctly

# PLOTTING ROUTINES -----------------------------------------------------------------------------------
# PLOTTING ROUTINES TAU PLOT
if plotTau == 'true':
    figTau = go.Figure()
    [zmin, zmax] = [elem_tau_p.min() / 10 ** 6, elem_tau_p.max() / 10 ** 6]
    for i in range(numElem):
        elemNodes = elemVec[i, :]  # Get the nodes
        coordS = nodeCoor[elemNodes]
        if elemType[i] == 0:
            if elemInt[i] == 0:
                t = elem_tau_p[i, 0] / 10 ** 6
                figTau.add_trace(go.Contour(
                    z=[[t, t], [t, t]],
                    x=[coordS[0, 0], coordS[1, 0]],  # horizontal axis
                    y=[coordS[0, 1], coordS[3, 1]],  # vertical axis
                    zmin=zmin, zmid=0, zmax=zmax, contours=dict(coloring='heatmap'),
                    colorbar=dict(title='tau [MPa]', titleside='right',
                                  titlefont=dict(size=14, family='Arial, sans-serif'))))
            elif elemInt[i] == 1:
                t = elem_tau_p[i, :] / 10 ** 6
                figTau.add_trace(go.Contour(
                    z=[[t[0], t[1]], [t[3], t[2]]],
                    x=[coordS[0, 0], coordS[1, 0]],  # horizontal axis
                    y=[coordS[0, 1], coordS[3, 1]],  # vertical axis
                    zmin=zmin, zmid=0, zmax=zmax, contours=dict(coloring='heatmap'),
                    colorbar=dict(title='tau [MPa]', titleside='right',
                                  titlefont=dict(size=14, family='Arial, sans-serif'))))
        elif elemType[i] == 1:
            coordS[3, :] = [coordS[1, 0], coordS[2, 1]]
            t = elem_tau_p[i, :] / 10 ** 6
            figTau.add_trace(go.Contour(
                z=[[t[0], t[1]], [t[3], 0]],     # Assume 0 in last point
                x=[coordS[0, 0], coordS[1, 0]],  # horizontal axis
                y=[coordS[0, 1], coordS[3, 1]],  # vertical axis
                zmin=zmin, zmid=0, zmax=zmax, contours=dict(coloring='heatmap'),
                colorbar=dict(title='tau [MPa]', titleside='right',
                              titlefont=dict(size=14, family='Arial, sans-serif'))))
    figTau.update_layout(
        title=go.layout.Title(text="Shear force 'tau' in [MPa]", xref="paper", x=0),
        xaxis=go.layout.XAxis(title=go.layout.xaxis.Title(text="x coordinate in [m]", font=dict(
            family="Courier New, monospace", size=18, color="#7f7f7f"))),
        yaxis=go.layout.YAxis(title=go.layout.yaxis.Title(text="y coordinate in [m]", font=dict(
            family="Courier New, monospace", size=18, color="#7f7f7f"))))
    figTau.show()

# TIMING ROUTINES -----------------------------------------------------------------------------------
tocT = timeit.default_timer()  # End time
print('Total Elapsed execution time =', (tocT - tic) * 1000, '[ms]')  # Print out total program execution time
print('FEA Elapsed execution time =', (toc0 - tic) * 1000, '[ms]')  # Print out execution time for FEA
print('K @ u = f, Elapsed execution time =', (tocK - ticK) * 1000, '[ms]')  # Print out execution time for Kuf
print(d.min() * 1000, 'd.min [mm]', d.max() * 1000, 'd.max [mm]')
