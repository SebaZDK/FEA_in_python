import math
import numpy as np
from numpy import ix_


def magnitude(vector):
    return math.sqrt(sum(pow(element, 2) for element in vector))


def kelem2d(nodes, E, G, A, I, loadvec):
    loadvec = loadvec.T[0]  # Unpack from double array to array

    vec = np.array([nodes[1, :] - nodes[0, :]])  # Vector for element
    vec = vec[0]  # Unpack
    length = magnitude(vec)  # Get the length
    print(length)
    # Stiffness
    phi = ((12 * E * I) / ((G * A[1]) * length ** 2))  # Phi to account for shear effects
    axialStiff = np.array([[1, -1], [-1, 1]]) * E * A[0] / length  # Axial stiffness

    # Define bending Y parameters
    y1 = 12 / (length ** 3)
    y2 = 6 / (length ** 2)
    y3 = (4 + phi) / length
    y4 = (2 - phi) / length
    y3 = y3[0][0]  # ??? For some reason double unpacking????
    y4 = y4[0][0]
    kebly = np.array([[y1, y2, -y1, y2], [y2, y3, -y2, y4], [-y1, -y2, y1, -y2], [y2, y4, -y2, y3]])
    kebly = (kebly * E * I) / (1 + phi)
    # Setup local stiffness matrix
    kelocal = np.zeros([6, 6])  # Local stiffness matrix initialised
    axDOF = [0, 3]
    bDOFy = [1, 2, 4, 5]
    kelocal[ix_(axDOF, axDOF)] = axialStiff  # Axial top row
    kelocal[ix_(bDOFy, bDOFy)] = kebly

    # Stress stiffening
    N0 = loadvec[3]  # Extract the normal forces
    s1 = 36  # From shape functions
    s2 = 3 * length  # -||-
    s3 = 4 * length ** 2
    s4 = length ** 2
    kesbly = np.array([[s1, s2, -s1, s2], [s2, s3, -s2, -s4], [-s1, -s2, s1, -s2], [s2, -s4, -s2, s3]]) * N0 / (
            30 * length)
    for i in range(4):
        for j in range(4):
            kelocal[bDOFy[i], bDOFy[j]] += kesbly[i, j]  # Index all stresses in bending over y axis

    # Create transformation matrix
    s = vec[1]
    c = vec[0]
    T = np.array([[c, s, 0, 0, 0, 0], [-s, c, 0, 0, 0, 0], [0, 0, length, 0, 0, 0],
                  [0, 0, 0, c, s, 0], [0, 0, 0, -s, c, 0], [0, 0, 0, 0, 0, length]]) / length

    # Ready to transform local stiffness matrix
    kelocal = T.transpose() @ kelocal @ T  # Matrix multiplication is done by @ handle

    # Include forces that are given : if they so are??
    fe = np.zeros([6, 1])
    fe[0:3, 0] = loadvec[0:3] * 0.5 * length  # Include those forces in x, y, M
    fe[3:6, 0] = loadvec[0:3] * 0.5 * length

    return kelocal, fe


def felem(nodes, E, G, A, I, loadvec, de, scales):
    vec = np.array([nodes[1, :] - nodes[0, :]])  # Vector for element
    vec = vec[0]  # Unpack
    length = magnitude(vec)  # Get the length

    # Transformation vector
    s = vec[1]
    c = vec[0]
    T = np.array([[c, s, 0, 0, 0, 0], [-s, c, 0, 0, 0, 0], [0, 0, length, 0, 0, 0],
                  [0, 0, 0, c, s, 0], [0, 0, 0, -s, c, 0], [0, 0, 0, 0, 0, length]]) / length

    # Internal forces get ----------------------------------------------

    [Ke, Fe] = kelem2d(nodes, E, G, A, I, loadvec)  # Get stiffness matrix and internal forces
    fe = Ke @ de.reshape(6, 1)  # Calculate  forces
    # fe = fe / length  # Normalise to length

    # Determine internal forces:
    feLocal = T @ fe

    # Get Forces:
    Nel = -feLocal[0]  # Constant axial force          (Why 6 is not used)
    Qel = feLocal[1]  # Shear force y , z (Why 7 and 8 is not used)
    MelY = np.array([feLocal[2], -feLocal[5]])  # Bending about y ( linear )

    elemForce = np.array([-Nel, Qel, -MelY[0], (-1 * MelY[1])])  # Cross sectional forces
    elemStrain = np.array([elemForce[0] / (E * A[0]), elemForce[1] / (G * A[1])[0], elemForce[2] / (E * I),
                           elemForce[3] / (E * I)])  # Normalised strain

    Vhat = np.array([(-vec[1], vec[0])]) / length  # Create orthogonal array (vector)

    nanH = np.array([np.nan, np.nan])  # Create a nan array to seperate plot figures

    # 10**(-3) is the conversion from N to kN in the output
    N2P = nodes + (10 ** (-3)) * Vhat * Nel * scales['intForceScale'][1]  # Determine new locations
    NeXY = np.vstack([N2P, nanH])

    Q2P = nodes + (10 ** (-3)) * Vhat * Qel * scales['intForceScale'][2]
    QeXY = np.vstack([Q2P, nanH])

    M2P1 = nodes[0, :] + np.array([10 ** (-3), 10 ** (-3)]) * Vhat * MelY[0] * scales['intForceScale'][3]
    M2P2 = nodes[1, :] + np.array([10 ** (-3), 10 ** (-3)]) * Vhat * MelY[1] * scales['intForceScale'][3]
    MeXY = np.vstack([np.vstack([M2P1, M2P2]), nanH])

    return elemForce, elemStrain, NeXY, QeXY, MeXY, Nel  # Output


def KufSolve(K, d, f, r, forceKnown, dispKnown, analysisMode):
    # Solve system of equations: ---------------------------------------------------------------------------------------
    f1 = forceKnown.T
    f1 = f1[0]  # Unpacking for python
    d1 = dispKnown.T
    d1 = d1[0]

    detK = np.linalg.det(K[ix_(f1, f1)])  # Help function ix_ allows for MATLAB like indexing
    if detK == 0:
        sys.exit('There is no stiffness in your system')
    elif detK < 0:
        sys.exit('There is negative stiffness in your system')

    match analysisMode:
        case 'static':
            As = K[ix_(f1, f1)]  # A in A*x = B corresponds to K in K*u = f
            Bs = f[f1] - K[ix_(f1, d1)] @ d[d1]  # B in A*x = B corresponds to f in K*u = f
            d[f1] = np.linalg.solve(As, Bs)  # Determines u in K*u = f
            Xs = d[f1]  # Defines a variable
            answer = np.allclose(np.dot(As, Xs), Bs)  # Checking that the solution is correct to tolerance
            print('Is the static solution correct?', answer)  # Writes out answer

    # Calculate reactions in supported nodes
    r[d1] = K[ix_(d1, d1)] @ d[d1] + K[ix_(d1, f1)] @ d[f1] - f[d1]

    return d, f, r


def getDOF(i, nodeLin, globalDOF):
    nodeS = int(nodeLin[i, 0])  # Get the node we are looking at
    nodeDOF = int(nodeLin[i, 1])  # Get the local DOF
    yy = globalDOF[nodeS]  # Get the array row
    yy = yy[0]  # Unpack it from array of array, to type array
    DOF = yy[int(nodeDOF)]  # Get the global index for the local DOF
    return DOF
