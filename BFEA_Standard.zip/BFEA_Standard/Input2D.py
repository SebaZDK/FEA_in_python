import numpy as np
import math
# A finite element program in 2D by Sebastian Rosleff, inspired (heavily) by L.V.A's MALTAB 2D timoskenko beam program
# 3D version is coming soon, static calculation engine and force generation is already working

# Normal node springs are implemented
# Right now only static mode is enabled, as this is the primary goal (To be used in bachelors)
# The figure table is interactive, to pressing on the side legend disables the view elements

# Coordinates         x, y
# nodeCoor = np.array([[0, 0], [1, 0], [2, 0], [3, 0], [4, 0], [5, 0], [6, 0]])  # Node coordinates
# elemVec = np.array([[0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 6]])  # Nodes that are connected by elements

num = 200        # Number of nodes
nodeCoor = np.array([[0, 0]])
elemVec = np.array([[0, 1]])
for j in range(num):
    nodeCoor = np.vstack([nodeCoor, [j + 1, 0]])
for j in range(1, num):
    elemVec = np.vstack([elemVec, [j, j + 1]])
nodeCoor = 0.05 * nodeCoor

# Material parameters (All values are in SI)-----------------------------------------------------
E = np.array([[2.1*10**11], [2.1 * 10 ** 11]])  # stiffness in N/m^2
nu = np.array([[0.3], [0.15]])  # Poisson's ratio
rho = np.array([[7850], [2500]])  # Density in kg/m^3
# G = np.array([[E[0] / (2 * (1 + nu[0]))], [E[1] / (2 * (1 + nu[1]))]])  # Shear modulus of the beam
G = np.array([[E[0] / (2 * (1 + nu[0]))], [E[1] / (2 * (1 + nu[1]))]])
fy = np.array([[235*10**6], [40*10**6]])  # 'Yield' stress for steel and concrete C40.
radii = 0.05 # radius in meters

# Cross-sectional parameters----------------------------------------------
#          Area x and shear area in y
A = np.array([[0.1 * 0.1, (5 / 6) * 0.1 * 0.1],  # 1 is for a beam, 2 is for circular rod
              [((radii)**2) * np.pi, ((radii)**2) * np.pi]])

# 2nd moment of area in m^4 y
# Ibeam = np.array([[1.0 * 10 ** (-4)], [1.0 * 10 ** (-4)]])
Ibeam = np.array([[(0.1**4) / 12], [(np.pi/4) * ((radii)**4)]])  # 1st is beam, 2nd is rod

# Maximum distance from bending center to outer fiber:
zMax = np.array([[0.05], [radii]])  # For beam and circular tube


# Assignment of materials and cross-section parameters: (human numbers)
materialParameters = np.ones((len(elemVec)))  # Creates a vector storing the index of the material assigned
sectionParameters = 2 * np.ones((len(elemVec)))  # Same but for cross-sections

# Loads and boundary conditions-------------------------------------
# Put in as python numbers, so DOF 1 (x) is indexed as 0, DOF 2 (y) as 1
# Forces         Node , DOF, Magnitude  (Apply in N)
# forces = np.array([[3, 1, 100 * 10 ** 3], [3, 0, 100 * 10 ** 3], [3, 2, -500 * 10 ** 3]])  # Forces to be applied to the model
# forces = np.array([[3, 0, 100 * 10 ** 3]])  # Forces to be applied to the model
forces = np.array([[num/2, 1, -1 * 10 ** 3]])  # Forces to be applied to the model

# greenfieldForces = 'true'
                 # d_ini (m) x,  y,    M , H (m) , D (m)
# infoGFD = np.array([0,         -0.2,  0,   5,    radii])
# stiffSoil = np.array([['1000 * math.log(xx + 1)', '10000 * math.log(xx + 1)', '1000 * math.log(xx + 1)']])  # Function for x, y, and moment in soil movement for transfer.

# Boundary conditions
# Displacement BD. node, DOF, imposed displacement
dispBound = np.array([[0, 0, 0], [0, 1, 0], [num, 1, 0]])
# dispBound = np.array([[0, 0, 0], [0, 1, 0], [0, 2, 0]])
# dispBound = np.array([[0, 0, 0]])

# Elastic or full releases:
#            Element, Node, DOF, Stiffness
# releaseDOF = np.array([[2, 0, 2, 0]])          # No duplicate entries
# releaseDOF = []  # np.array([[0, 0, 2, 100000]]) # Just need to remove the original DOF and it works then

# Standardised springs
#            Node, DOF, stiffness (Not implemented yet)
# springs = np.array([[6, 1, 1.0 * 10**6], [6, 0, 1.0 * 10**6], [0, 1, 1.0 * 10**6]])
# springs = np.array([[6, 0, 1.0 * 10**6], [1, 0, 1.0 * 10**6]])
# springs = np.array([[0, 0, 1.0 * 10**4], [0, 1, 1.0 * 10**4], [1, 0, 1.0 * 10**4], [1, 1, 1.0 * 10**4], [2, 0, 1.0 * 10**4], [2, 1, 1.0 * 10**4],
#                     [3, 0, 1.0 * 10**4], [3, 1, 1.0 * 10**4], [4, 0, 1.0 * 10**4], [4, 1, 1.0 * 10**4], [5, 0, 1.0 * 10**4], [5, 1, 1.0 * 10**4],
#                     [6, 0, 1.0 * 10**4], [6, 1, 1.0 * 10**4]])

# non - linear springs
#                     Force function,  max deformation (m), start def (m) step increase (m)
# linSprings = np.array([['2000*x[i] + 200', 1, 0.5, 0.05], ['2000', 10, 1, 0.1], ['20000', 1000, 100, 0.1]])  #, [1.0 * 10**3, 10**(-3), 10**3]])

# Node values for linSprings
#                Node, DOF
# nodeLin = np.array([[0, 1], [1, 1], [2, 1], [3, 1], [4, 1], [5, 1], [6, 1]])
# nodeLin = np.array([[0, 1], [1, 1], [2, 1], [3, 1], [4, 1], [5, 1], [6, 1]])

# Modes---------------------------------------------------
analysisMode = 'static'  # static
# selfWeight = 'true'  # Include self weight in calculation
selfWeight = 'false'  # Include self weight in calculation
showFigures = 'true'  # Display figures?
showForces = 'true'
showReactions = 'true'
plotMoments = 'true'  # Want moments in plots??
stressStiffening = 'false'    # yes or no. If included, runtime must be clicked twice to generate files and load loads
resetStress      = 'true'     # All stresses will be reset, This should be turned off for the 2nd run such that the initial stress file is loaded

# Modifiers ----------------------------------------------
displacementScale = 10**(0)  # Default, 1m displacement is 1m in figure
forceScale = (0)  # Default is 0, so it is in kN, size of force vectors
#                  Global, N, Q, M
intForceScale = np.array([(0), 1.0 * 10 ** (0), 1.0 * 10 ** (0), 1.0 * 10 ** (0)])  # Default, size of internal forces
numElemPoints = 9  # Standard

# Indexing into structure to access later
scales = {"displacementScale": displacementScale, "forceScale": forceScale, "intForceScale": intForceScale,
          "numElemPoints": numElemPoints}
