import sys
import plotly.graph_objects as go
import plotly.io as pio
from numpy import ix_
from plotly.subplots import make_subplots
import plotly.figure_factory as ff
import pandas as pd
from Input2D import *  # Imports all variables
import math

pio.renderers.default = 'browser'  # Opens browser for figure plotting
from StiffFunc2D import *

# io.loadmat('data.mat') Can load MATLAB arrays
numDOF = 3  # Number of DOF per 3D nodes, without warping
numNodes = len(nodeCoor)  # Returns the number of nodes in model
numElem = len(elemVec)  # Returns number of elements
numGlobalDOF = numNodes * numDOF  # Number of total DOF's
if "dispBound" in globals():
    numDispBound = len(dispBound)  # Number of displacement boundary conditions
else: numDispBound = 0
if "forces" in globals():
    numForceBound = len(forces)  # Number of force imposed on structure
else: numForceBound = 0
numMaterials = len(materialParameters)  # Number of materials
numSections = len(sectionParameters)  # Number of sections

if showFigures == 'true':
    x1 = np.zeros(3 * numNodes)  # Reset vectors for plotting
    y1 = np.zeros(3 * numNodes)

    for i in range(elemVec.shape[0]):  # For every element
        elemNodes = elemVec[i, :]  # Get the nodes
        coord = nodeCoor[elemNodes]  # Node coordinates are found
        x1[3 * i:3 * i + 3] = np.hstack([coord[:, 0], np.nan])  # indexing all x plus an extra nan node
        y1[3 * i:3 * i + 3] = np.hstack([coord[:, 1], np.nan])

    if showForces == 'false' and showReactions == 'false':  # Do not plot forces
        geometryPlot = go.Figure()
        geometryPlot.add_trace(go.Scatter3d(x=x1, y=y1, name="Systems of elements", line
        =dict(color='blue', width=10), marker=dict(size=10, color='white')))
        go.Figure(data=geometryPlot).show()

        geom = make_subplots(rows=2, cols=2, specs=[[{'type': 'scatter'}, {'type': 'scatter'}],
                                                    [{'type': 'scatter'}, {'type': 'scatter'}]],
                             subplot_titles=("Geometry", "Normal force", "Shear force", "Moments in Y"))  # Prepare figure
        geom.add_trace(go.Scatter(x=x1, y=y1, name="Systems of elements", line  # Plot figure 1 (Geometry)
        =dict(color='blue', width=10), marker=dict(size=10, color='white')), row=1, col=1)
        geom.add_trace(go.Scatter(x=x1, y=y1, name="Systems of elements", line
        =dict(color='blue', width=5), marker=dict(size=20, color='white')), row=1, col=2)
        geom.add_trace(go.Scatter(x=x1, y=y1, name="Systems of elements", line
        =dict(color='blue', width=5), marker=dict(size=20, color='white')), row=2, col=1)
        geom.add_trace(go.Scatter(x=x1, y=y1, name="Systems of elements", line
        =dict(color='blue', width=5), marker=dict(size=20, color='white')), row=2, col=2)
    else:
        # subplot setup
        subplots = make_subplots(rows=2, cols=2, x_title='Model length in meters', y_title='Force or displacement magnitude',
                                 subplot_titles=("Geometry", "Normal force", "Shear force", "Moments in Y"))
else:
    print("showFigures = 'false, therefore not displaying figures :)")

numNodalDOF = np.ones((numNodes, 1)) * numDOF  # Every node has 6 DOF's in 3D here
if 'releaseDOF' in globals() and len(
        releaseDOF) != 0:  # If release exist and isn't# io.loadmat('data.mat') Can load MATLAB arrays [] empty
    numDOFRel = int(releaseDOF.size / 4)  # Obtains number of releases in total
    numGlobalDOF += numDOFRel  # Updates global number of DOF's
    for i in range(numDOFRel):  # Loops over number of released DOF's
        elem = releaseDOF[i, 0]  # Gets Element number
        node = releaseDOF[i, 1]  # Node 1 or node 2????
        elemNodes = elemVec[elem, :]  # Obtains the element nodes
        globalNode = elemNodes[node]
        numNodalDOF[globalNode] += 1  # Adds an extra node

# Get the global DOF for each node:
globalDOF = np.empty([numNodes], dtype=object)  # Create an empty array of arrays
globalDOF = np.reshape(globalDOF,
                       (numNodes, 1))  # Reshape it to be a column vector (Python does not know this, don't tell her)
globalDOF3 = np.zeros([numNodes, 3])  # Used later for data storage
dofEnd = 0  # Create an starting value
for i in range(numNodes):  # Over all nodes from 0 to end
    if i == 0:
        dofStart = dofEnd  # Starting node
        dof6 = dofEnd + 3  # Last node in rearranged output
    else:
        dofStart = dofEnd  # Starting node
        dof6 = dofEnd + 3  # Last node in rearranged output
    dofEnd += int(numNodalDOF[i])  # True last DOF for the specific node
    globalDOF[i, 0] = np.asarray(list(range(dofStart, dofEnd)))  # The global DOF numbers unarranged
    globalDOF3[i, :] = np.asarray(list(range(dofStart, dof6)))  # The global DOF arranged
globalDOF3 = np.reshape(globalDOF3, (globalDOF3.size, 1))  # Reshaping to a list for later use

# Setup global indexing of elements
elemGlobalDOF = np.zeros([numElem, 6])  # Create matrix for storing DOF's later
for i in range(numElem):  # For every element
    elemNodes = elemVec[i, :]  # Get the nodes
    ktemp1 = globalDOF[elemNodes[0], :]  # Retrieve the array of the array globalDOF
    ktemp2 = globalDOF[elemNodes[1], :]
    ktemp1 = (ktemp1[0])  # Unpack the array such that it's just an array
    ktemp2 = (ktemp2[0])
    elemGlobalDOF[i, np.asarray(list(range(3)))] = ktemp1[np.asarray(list(range(3)))]  # Index into the elemGlobalDOF
    elemGlobalDOF[i, np.asarray(list(range(3, 6)))] = ktemp2[np.asarray(list(range(3)))]

# Stress stiffening  checker
if stressStiffening == 'true':  # If we wanna work with stress stiffining
    if resetStress == 'true':  # Do we want it reset?
        initialN = np.zeros([numElem, 1])  # If yes, no stresses are used again
    elif resetStress == 'false':  # If no
        initialN = np.load('initialStresses.npy')  # Use previously calculated stresses
# If elastic releases exist, introduce them now:
if 'releaseDOF' in globals() and len(releaseDOF) != 0:  # Checking for variable
    if releaseDOF.shape[1] == 4:  # If elastic parameter is defined
        coupleGlobalDOF = np.zeros([numDOFRel, 3])  # Create vector
    numNodalDOF = np.ones((numNodes, 1)) * numDOF  # Resetting the array
    for i in range(numDOFRel):  # Counting over the number of releases
        elem = releaseDOF[i, 0]  # Getting the element with the release
        node = releaseDOF[i, 1]  # Getting the node
        DOF = releaseDOF[i, 2]  # Getting the DOF with the release
        localDOF = numDOF * (node - 1) + DOF  # The local DOF
        elemNodes = elemVec[elem, :]  # The nodes
        globalNode = elemNodes[node]  # Determine the global indexing
        numNodalDOF[globalNode] += 1  # Add 1
        yy = globalDOF[globalNode]  # Get the array row
        yy = yy[0]  # Unpack it from array of array, to type array
        yy = yy[int((numNodalDOF[globalNode])) - 1]  # get the value from the index of the node from that array
        elemGlobalDOF[elem, localDOF] = yy  # Replace the DOF
        if releaseDOF.shape[1] == 4:  # If elastic parameter is defined
            stiffness = releaseDOF[i, 3]  # Get float of the stiffnedd
            yy = globalDOF[globalNode]  # Get the array row
            yy = yy[0]  # Unpack it from array of array, to type array
            yy = yy[int(DOF)]  # get the value from the index of the node from that array
            coupleGlobalDOF[i, [0, 1, 2]] = [yy, int(elemGlobalDOF[elem, localDOF]), stiffness]  # Couple the DOF's

# Assemble system of equations for the matrices------------------------------------
tempK = np.zeros((numGlobalDOF, numGlobalDOF))  # Create temperary stiffness matrix
K = tempK.copy()  # Cannot calculate det(K) in python for sparce
# K = scipy.sparse.lil_matrix(tempK)                      # Convert it to sparce matrix to same memory
KSpring = tempK.copy()  # Stiffness matrix for springs
KSoil = tempK.copy()    # Used for calculating forces on soil
KLinSprings = tempK.copy()  # Stiffness matrix for springs
f = np.zeros([numGlobalDOF, 1])  # Force vector for output
d = np.zeros([numGlobalDOF, 1])  # Displacement vector for output
r = np.zeros([numGlobalDOF, 1])  # Reaction vector for output
dispVec = np.zeros([numGlobalDOF, 1])  # Displacement vector
elemForce = np.zeros([numElem, 4])  # Element force vector
elemStrain = np.zeros([numElem, 4])  # Element strain vector

# Setup for K * u = f. First setup the force part. Assumption, all forces are known, no displacements are known
dispKnown = np.zeros([numGlobalDOF, 1], dtype=bool)  # All displacements are unknown
forceKnown = np.ones([numGlobalDOF, 1], dtype=bool)  # All forces are known

# However some displacements are known, those are the boundary conditions:
for i in range(numDispBound):  # For all boundary conditions
    nodeBC = dispBound[i, 0]  # Get the node we are looking at
    nodeDOF = dispBound[i, 1]  # Get the local DOF
    valDOF = dispBound[i, 2]  # Get the displacement value
    yy = globalDOF[nodeBC]  # Get the array row
    yy = yy[0]  # Unpack it from array of array, to type array
    DOF = yy[int(nodeDOF)]  # Get the global index for the local DOF
    dispKnown[DOF] = not dispKnown[DOF]  # Switch the bool to true
    forceKnown[DOF] = not forceKnown[DOF]  # Switch the bool to false
    d[DOF] = valDOF  # Assign known displacement to displacement vector
# Also some forces are known, these will be implemented now:
for i in range(numForceBound):
    nodeBC = forces[i, 0]  # Get the node we are looking at
    nodeDOF = forces[i, 1]  # Get the local DOF
    valDOF = forces[i, 2]  # Get the force magnitude
    yy = globalDOF[int(nodeBC)]  # Get the array row
    yy = yy[0]  # Unpack it from array of array, to type array
    DOF = yy[int(nodeDOF)]  # Get the global index for the local DOF
    f[DOF] = valDOF  # No boolean switch required, first assumption == true

# Assemble matrices
for i in range(numElem):
    elemNodes = elemVec[i, :]  # Load all element nodes
    elemDOF = elemGlobalDOF[i, :]  # Load all DOF's
    elemCoordinate = nodeCoor[elemNodes, :]  # Get all coordinates
    mat = int(materialParameters[i]) - 1  # Gets the type of material
    sec = int(sectionParameters[i]) - 1  # Gets the cross-section
    loadVec = np.zeros([4, 1])  # Load vector x,y, m (4th entry is for stress stiffening
    if 'rho' in globals() and selfWeight == 'true':
        loadVec[1] = -rho[mat] * A[sec, 0] * 9.82  # Define self weight per meter
    if 'initialN' in globals():
        loadVec[3] = initialN[i]  # Include stress stiffining
    [kLocal, fLocal] = kelem2d(elemCoordinate, E[mat], G[mat], A[sec], Ibeam[sec], loadVec)
    eD = elemDOF.T  # From column to row vector, python doesn't like column
    eD = eD.astype(int)  # Convert from type float array to type integer array
    print(kLocal)
    print(K[ix_(eD, eD)], 'Should be 0')
    K[ix_(eD, eD)] += kLocal  # Indexing kLocal into K global, using the ix_ command
    print(K[ix_(eD, eD)], 'Should be equal to Ke')
    f[eD] += fLocal  # Adding forces

# Add Nodal springs
if 'springs' in globals() and len(springs) != 0:
    numSprings = int(springs.shape[0])
else:
    numSprings = 0

for i in range(numSprings):  # For all spring boundary conditions
    nodeS = int(springs[i, 0])  # Get the node we are looking at
    nodeDOF = int(springs[i, 1])  # Get the local DOF
    valStiff = springs[i, 2]  # Get the stiffness of the spring
    yy = globalDOF[nodeS]  # Get the array row
    yy = yy[0]  # Unpack it from array of array, to type array
    DOF = yy[int(nodeDOF)]  # Get the global index for the local DOF
    KSpring[DOF, DOF] = valStiff  # Index the stiffness into that diagonal

if 'coupleGlobalDOF' in globals() and coupleGlobalDOF.shape[0] != 0:
    numElasRel = int(coupleGlobalDOF.shape[0])  # Get number of elastic releases
    for i in range(numElasRel):
        coupleDOF = coupleGlobalDOF[i, 0:2]  # Get the 2 DOF's
        stiff = coupleGlobalDOF[i, 2]  # Get the stiffness
        kCouple = np.array([[1, -1], [-1, 1]]) * stiff
        j1 = 0
        for j in coupleDOF:
            j = int(j)
            for k in range(2):
                K[j, int(coupleDOF[k])] += kCouple[j1, k]  # Insert stiffness
            j1 += 1


# Add normal global stiffness matrix and Spring stiffness matrix
K += KSpring  # This means: K = K + KSpring

if 'greenfieldForces' in globals() and greenfieldForces == 'true' and 'infoGFD' in globals():
    d_soil = np.zeros([numGlobalDOF,1])
    for i in range(numNodes):
        xx = infoGFD[0]
        d_soil[i * 3] = infoGFD[0]; KSoil[i * 3, i * 3] = eval(stiffSoil[0, 0])  ;
        xx = infoGFD[1]
        d_soil[i * 3 + 1] = infoGFD[1]; KSoil[i * 3 +1, i * 3 +1] = eval(stiffSoil[0, 1])  ;
        xx = infoGFD[2]
        d_soil[i * 3 + 2] = infoGFD[2];  KSoil[i * 3 + 2, i * 3 +2] = eval(stiffSoil[0, 2])  ;#Insert displacements
        FSoil = KSoil @ d_soil

if 'linSprings' in globals() and len(linSprings) != 0:
    numLin = linSprings.shape[0]  # Maximum number of lin springs
    numNodeLin = nodeLin.shape[0]  # Number of nodes supported this way
    SprArray = np.zeros([numNodeLin, 2])  # Create vector to store results
    for i in range(numNodeLin):
        SprArray[i, 1] = float(linSprings[int(SprArray[i, 0]), 2]) + float(linSprings[int(SprArray[i, 0]), 3])  # Initial guess
    maxF = np.zeros([numNodeLin, 1])  # Initiate maximum force vector the iteration
    springVec = np.zeros([numNodeLin, 1])  # Initiale stiffness vector for text plotting
    stopVar = 1  # Updates
    stopVarIni = 0
    f0 = f  # For saving original forces
    if 'FSoil' in globals():
        stopVar += 100  # Do at least 5 iterations if this is enabled
    while 'ans' != 'No further iteration is needed':
    # for ii in range(100):
        stopVarIni += 1
        K0 = K.copy()  # Create a copy of K original
        x = np.zeros([numNodeLin, 1])  # Reset parameter
        for i in range(numNodeLin):  # For all spring boundary conditions
            nodeS = int(nodeLin[i, 0])  # Get the node we are looking at
            nodeDOF = int(nodeLin[i, 1])  # Get the local DOF
            yy = globalDOF[nodeS]  # Get the array row
            yy = yy[0]  # Unpack it from array of array, to type array
            DOF = yy[int(nodeDOF)]  # Get the global index for the local DOF
            x[i] = SprArray[i, 1]  # Get the maximum displacement allowed for the current iteration
            maxF[i] = eval(linSprings[int(SprArray[i, 0]), 0])  # Obtain maximum force avaliable in this loadstep
            stiffA = maxF[i] / (x[i])  # Calculate stiffness ( force / displacement)
            KLinSprings[DOF, DOF] = stiffA  # Index the approximate stiffness into that diagonal
            springVec[i] = stiffA  # Save the stiffness
        if 'FSoil' in globals():
            for i in range (numNodes):
                for j in range (numDOF):
                    xx = d_soil[i * 3 + j] - d[i * 3 + j]  # Determine the actual settlement of the tie-rod compared to soil
                    KSoil[i * 3 + j, i * 3 + j] = eval(stiffSoil[0, j])
            FSoil = -KSoil @ d_soil
            print(FSoil)
            f = FSoil + f0  # Update soil structure forces...
        print(f)

        # Enough bullying around
        K0 += KLinSprings  # Adds the springs to K0
        [d, f, r] = KufSolve(K0, d, f, r, forceKnown, dispKnown, analysisMode)  # Solves the stiffness matrix
        for i in range(numNodeLin):  # For all spring boundary conditions
            nodeS = int(nodeLin[i, 0])  # Get the node we are looking at
            nodeDOF = int(nodeLin[i, 1])  # Get the local DOF
            yy = globalDOF[nodeS]  # Get the array row
            yy = yy[0]  # Unpack it from array of array, to type array
            DOF = yy[int(nodeDOF)]  # Get the global index for the local DOF
            if d[DOF] < -x[i]:  # If the displacement is 'above' the maximum allowed:
                if x[i] < eval(linSprings[int(SprArray[i, 0]), 1]):  # if the displacement is below the limit for this function part:
                    SprArray[i, 1] += eval(linSprings[int(SprArray[i, 0]), 3])  # Update the maximum disp by the allowed step
                    stopVar += 1  # Run analysis again
                elif x[i] == eval(linSprings[int(SprArray[i, 0]), 1]):  # If the loadstep = max in this disp curve:
                    SprArray[i, 0] += 1  # Get to the next loading part
                    SprArray[i, 1] = eval(linSprings[int(SprArray[i, 0]), 2])  # Get the starting disp from this part
                    stopVar += 1  # Run analysis again
        #     # Else do nothing
        # Now check if anything needs updating
        if stopVar == stopVarIni:
            ans = 'No further iteration is needed'
            print(ans)
            ans2 = 0
            for i in range(numNodeLin):  # Check all linear springs nodes
                nodeS = int(nodeLin[i, 0])  # Get the node we are looking at
                nodeDOF = int(nodeLin[i, 1])  # Get the local DOF
                yy = globalDOF[nodeS]  # Get the array row
                yy = yy[0]  # Unpack it from array of array, to type array
                DOF = yy[int(nodeDOF)]  # Get the global index for the local DOF
                if d[DOF] > x[i]:  # If any displacements are outside the allowed by the loadstep:
                    ans2 += 1  # Add one to ans2
            if ans2 != 0:  # Now if ans2 is not 0, something is wrong
                print('Solution is wrong as displacements exceed max, deformation allowed size')
            else:
                print('Support springs have converged')
            break  # terminate while loop
        else:
            ans = 'Further iteration is needed'
            print("Further iteration is needed")
        print('Loop is number: ', stopVarIni)

else:  # If not used, just do the original without iterative springs
    print(K)
    [d, f, r] = KufSolve(K, d, f, r, forceKnown, dispKnown, analysisMode)  # Solves the stiffness matrix

Ne = np.zeros([int(numElem) * 3, 2])
Qe = np.zeros([int(numElem) * 3, 2])
Me = np.zeros([int(numElem) * 3, 2])
for i in range(int(numElem)):  # Ready to calculate forces
    elemNodes = elemVec[i, :]  # Load all element nodes
    elemDOF = elemGlobalDOF[i, :].astype(int)  # Load all DOF's
    elemCoordinate = nodeCoor[elemNodes, :]  # Get all coordinates
    mat = int(materialParameters[i]) - 1  # Gets the type of material
    sec = int(sectionParameters[i]) - 1  # Gets the cross-section
    de = d[elemDOF]  # Get reference deformation parameters
    de = de.reshape(1, 6)  # Reshape from column to row
    [eForce, eStrain, NeXY, QeXY, MeXY, N0] = felem(elemCoordinate, E[mat], G[mat], A[sec, :], Ibeam[sec], loadVec, de,
                                                scales)
    Ne[i * 3:(i + 1) * 3] = NeXY  # Reshaping results for plotting
    Qe[i * 3:(i + 1) * 3] = QeXY
    Me[i * 3:(i + 1) * 3] = MeXY
    if 'initialN' in globals():
        initialN[i] = N0
    elemForce[i, :] = eForce.reshape(1, 4)  # Indexing the forces and strains
    elemStrain[i, :] = eStrain.reshape(1, 4)
# Save N0 to file
if 'initialN' in globals():
    np.save('initialStresses.npy', initialN)

# Now all forces are known and extracted
# Reshape arrays to match nodeCoor
d = d.reshape(numNodes, 3)
f = f.reshape(numNodes, 3)
r = r.reshape(numNodes, 3)

xDisp1 = np.zeros(3 * numElem)  # Reset vectors for plotting
yDisp1 = np.zeros(3 * numElem)
xDispO = nodeCoor[:, 0] + d[:, 0] * scales["displacementScale"]  # Creating the displacement nodes for plotting
yDispO = nodeCoor[:, 1] + d[:, 1] * scales["displacementScale"]
xDisp = xDispO.reshape(numNodes, 1)
yDisp = yDispO.reshape(numNodes, 1)
dispCoor = np.hstack([xDisp, yDisp])
for i in range(elemVec.shape[0]):  # For every element
    elemNodes = elemVec[i, :]  # Get the nodes
    coord = dispCoor[elemNodes]
    xDisp1[3 * i:3 * i + 3] = np.hstack([coord[:, 0], np.nan])  # indexing all x plus an extra nan node
    yDisp1[3 * i:3 * i + 3] = np.hstack([coord[:, 1], np.nan])
xDisp = xDisp1
yDisp = yDisp1

# Calculate and then print out spring forces if springs are attached
if 'linSprings' in globals() and len(linSprings) != 0:
    for i in range(numNodeLin):  # Check all linear springs nodes
        nodeS = int(nodeLin[i, 0])  # Get the node we are looking at
        nodeDOF = int(nodeLin[i, 1])  # Get the local DOF
        yy = globalDOF[nodeS]  # Get the array row
        yy = yy[0]  # Unpack it from array of array, to type array
        DOF = yy[int(nodeDOF)]  # Get the global index for the local DOF

        match nodeDOF:
            case 0:
                motion = 'Horizontal'
            case 1:
                motion = 'Vertical'
            case 2:
                motion = 'Moment'
        if i == 0:
            table = np.array([nodeS, nodeDOF, motion, round(d[nodeS, nodeDOF], 5), round(x[i][0], 5),
                              round(-d[nodeS, nodeDOF] * springVec[i][0] * 10 ** (-3), 5),
                              round(springVec[i][0] * 10 ** (-3), 5)])  # Converting for printing in kN
            indexVar = np.array([["Spring nr. ", str(i)]])  # Concatenate strings
            indexVar = np.array([[indexVar[0, 0] + indexVar[0, 1]]])  # Create list
        else:
            table1 = np.array([nodeS, nodeDOF, motion, round(d[nodeS, nodeDOF], 5), round(x[i][0], 5),
                               round(-d[nodeS, nodeDOF] * springVec[i][0] * 10 ** (-3), 5),
                               round(springVec[i][0] * 10 ** (-3), 5)])
            table = np.vstack([table, table1])
            indexVar1 = np.array([["Spring nr. ", str(i)]])
            indexVar1 = np.array([[indexVar1[0, 0] + indexVar1[0, 1]]])
            indexVar = np.vstack([indexVar, indexVar1])  # Add the lists
    printSpringsLin = pd.DataFrame(table,
                                   columns=["Node", "DOF", "Local motion", "Disp (m)", "Max(d) (m)", "Force (kN)",
                                            "k (kN/m)"], index=indexVar)
    print('―' * 40)  # print --- line in console
    print('Non-linear nodal winkler springs')
    print(printSpringsLin)  # Print out springs table
    print('―' * 40)

if 'springs' in globals() and len(springs) != 0:
    for i in range(numSprings):  # For all spring boundary conditions
        nodeS = int(springs[i, 0])  # Get the node we are looking at
        nodeDOF = int(springs[i, 1])  # Get the local DOF
        valStiff = springs[i, 2]  # Get the stiffness of the spring
        match nodeDOF:
            case 0:
                motion = 'Horizontal'
            case 1:
                motion = 'Vertical'
            case 2:
                motion = 'Moment'
        if i == 0:
            table = np.array([nodeS, nodeDOF, motion, round(d[nodeS, nodeDOF], 5),
                              round(-d[nodeS, nodeDOF] * valStiff * 10**(-3), 5), round(valStiff * 10**(-3),5)])  # Converting for printing in kN
            indexVar = np.array([["Spring nr. ", str(i)]])  # Concatenate strings
            indexVar = np.array([[indexVar[0, 0] + indexVar[0, 1]]])  # Create list
        else:
            table1 = np.array([nodeS, nodeDOF, motion, round(d[nodeS, nodeDOF], 5),
                               round(-d[nodeS, nodeDOF] * valStiff * 10**(-3), 5), round(valStiff * 10**(-3),5)])
            table = np.vstack([table, table1])
            indexVar1 = np.array([["Spring nr. ", str(i)]])
            indexVar1 = np.array([[indexVar1[0, 0] + indexVar1[0, 1]]])
            indexVar = np.vstack([indexVar, indexVar1])  # Add the lists
    printSprings = pd.DataFrame(table, columns=["Node", "DOF", "Local motion", "Displacement (m)", "Force (kN)",
                                                "k (kN/m)"], index=indexVar)
    print('Linear nodal winkler springs')
    print(printSprings)  # Print out springs table
    print('―' * 40)

for i in range(int(numElem)):
    elemNodes = elemVec[i, :]  # Load all element nodes
    if i == 0:
        tableE = np.array([int(elemNodes[0]), int(elemNodes[1])])
        tableE = np.hstack([tableE, elemForce[i]* 10 ** (-3)])
        indexVar = np.array([["Elem ", str(i)]])  # Concatenate strings
        indexVar = np.array([[indexVar[0, 0] + indexVar[0, 1]]])  # Create list
    else:
        tableE1 = np.array([int(elemNodes[0]), int(elemNodes[1])])
        tableE1 = np.hstack([tableE1, elemForce[i] * 10 ** (-3)])
        tableE = np.vstack([tableE, tableE1])
        indexVar1 = np.array([["Elem ", str(i)]])
        indexVar1 = np.array([[indexVar1[0, 0] + indexVar1[0, 1]]])
        indexVar = np.vstack([indexVar, indexVar1])  # Add the lists
printElem = pd.DataFrame(tableE, columns=["Node 1", "Node 2", "N (kN)" , "Q (kN)", "M1 (kN m)", "M2 (kN m)" ],
                                index=indexVar)

# Calculate tensile utilization of the cross-section: Elastic calculation based on EC1992 (eq 6.2)
utilElem = elemForce.__copy__()  # Copys the 4 by numElem array
for i in range(int(numElem)):
    mat = int(materialParameters[i]) - 1  # Gets the type of material
    sec = int(sectionParameters[i]) - 1  # Gets the cross-section
    utilElem[i, 0] = utilElem[i, 0] / (fy[mat] * A[sec, 0])  # Check normal force
    utilElem[i, 1] = utilElem[i, 1] / ((fy[mat] / np.sqrt(3)) * A[sec, 1])  # Check shear force (EC1992 (eq 6.18))
    utilElem[i, 2] = np.max([utilElem[i, 2], utilElem[i, 3]]) / ((fy[mat]/zMax[sec]) * Ibeam[sec])  # Check moment
    utilElem[i, 3] = magnitude(utilElem[i, :3])  # Pythagoas function, failure criterion from EC1992 6.2
    if utilElem[i, 0] < -1:
        print("Normal tensile force exceeds resistance in member: ", i)
    if utilElem[i, 1] > 1:
        print("Shear force exceeds resistance in member: ", i)
    if utilElem[i, 2] > 1:
        print("Bending moment exceeds resistance in member: ", i)
    if utilElem[i, 3] > 1:
        print("Combined failure resistance in member: ", i)
printUtil = pd.DataFrame(utilElem, columns=["Util N", "Util Q", "Util M", "Util Combined"], index=indexVar)

# Print out the various tables:
print('―' * 40)
print(printUtil)  # Print out utilization table
print('―' * 40)
print(printElem)  # Print out elem table
print('―' * 40)

if showFigures == 'true':
    for i in range(numNodes):
        if i == 0:
            nodeText = np.array([["N ", str(i)]])  # Concatenate strings
            nodeText = np.array([[nodeText[0, 0] + nodeText[0, 1]]])  # Create list
        else:
            nodeText1 = np.array([["N ", str(i)]])
            nodeText1 = np.array([[nodeText1[0, 0] + nodeText1[0, 1]], [nodeText1[0, 0] + nodeText1[0, 1]],
                                  [nodeText1[0, 0] + nodeText1[0, 1]]])
            nodeText = np.vstack([nodeText, nodeText1])
    for i in range(int(numElem)):
        if i == 0:
            elemText = np.array([["E", str(i)]])  # Concatenate strings
            elemText = np.array([[elemText[0, 0] + elemText[0, 1]]])  # Create list
        else:
            elemText1 = np.array([["E", str(i)]])
            elemText1 = np.array([[elemText1[0, 0] + elemText1[0, 1]], [elemText1[0, 0] + elemText1[0, 1]],
                                  [elemText1[0, 0] + elemText1[0, 1]]])
            elemText = np.vstack([elemText, elemText1])

    if showForces == 'false' and showReactions == 'false':
        # Update figures:
        geom.add_trace(
            go.Scatter(x=x1, y=y1, mode='markers', name="Original nodes", marker=dict(color='grey', size=10)), row=1,
            col=1)
        geom.add_trace(go.Scatter(x=xDisp, y=yDisp, name="Displaced elements", mode="lines+markers", line  # Plot figure 1 (Geometry)
        =dict(color='orange', width=10), marker=dict(size=10, color='white')), row=1, col=1)
        subplots.add_trace(go.Scatter(x=xDisp, y=yDisp, name="Node Numbers", mode="text", text=nodeText,  # Only add note text...
                   textposition="bottom center",textfont=dict(family="AU bold", size=15, color="Black")), row=1, col=1)
        subplots.add_trace(go.Scatter(x=xDisp, y=yDisp, name="Element Numbers", mode="text", text=elemText, # Only add element text
                  textposition="top right", textfont=dict(family="AU bold", size=15, color="Black")), row=1, col=1)

        geom.add_trace(go.Scatter(x=Ne[:, 0], y=Ne[:, 1], name="Normal Force (kN)", mode="lines+markers", line  # Plot normal
        =dict(color='yellow', width=2)), row=1, col=2)
        geom.add_trace(go.Scatter(x=Qe[:, 0], y=Qe[:, 1], name="Shear Force (kN)", mode="lines+markers", line  # Plot shear
        =dict(color='red', width=2)), row=2, col=1)
        geom.add_trace(go.Scatter(x=Me[:, 0], y=Me[:, 1], name="Bending moment kN*m", mode="lines+markers", line  # Plot moments in fig 4
        =dict(color='green', width=2)), row=2, col=2)

        go.Figure(data=geom).show() # Show the figures
    else:
        # The following section is done solely to plot quivers in 2D. Python is quite picky.
        # E.g. You cannot update a quiver series with custom colour in subplots, so it's technically
        # impossible to actually plot forces and reactions in seperate colours.
        count = 0   # Count of forces
        countR = 0   # Count of reactions
        for i in range(len(f)):  # Get the number of nodes
            for j in range(3):   # Number of DOF's per node
                if f[i, j] != 0:  # If the external force in the DOF isn't = 0
                    if plotMoments == 'false' and j == 2:  # Sometimes moments are annoying
                        print('Moments are excluded from plots')
                    else:
                        count += 1  # Else state we have a force
                        if 'numVar' not in globals():  # If numVar doesnt exist
                            numVar = np.array([i, j])  # Create array
                        else:
                            numVar = np.vstack([numVar, np.array([i, j])])  # Else update with new row
        for i in range(len(r)):  # Do the same thing but for reactions only
            for j in range(3):
                if r[i, j] != 0:
                    if plotMoments == 'false' and j == 2:
                        print('Moments are excluded from plots')
                    else:
                        countR += 1
                        if 'numVarR' not in globals():
                            numVarR = np.array([i, j])
                        else:
                            numVarR = np.vstack([numVarR, np.array([i, j])])
        ## Create xx = x coordinate for plotting the quivers
        xx = np.zeros([count, 1])
        yy = np.zeros([count, 1])
        uu = np.zeros([count, 1])  # u = x span
        vv = np.zeros([count, 1])  # v = y span

        for i in range(count):  # Get the node coordinates for the nodes with
            if count == 1:  # If there is only 1 force acting on the structure
                nodeC = nodeCoor[numVar[0], :]  # Extract coordinates from original geometry
                xx[i] = nodeC[0]  # Unpack and retrieve the 2 x coordinate values
                yy[i] = nodeC[1]  # Same but for y
                j = numVar[1]  # Get if its acting in (x, y,  moment)
                if j == 0:
                    uu[i] = f[numVar[0], j]   # If acting in the x direction, only have the force plotted in x
                elif j == 1:
                    vv[i] = f[numVar[0], j]  # Same but for y
                elif j == 2:
                    uu[i] = f[numVar[0], j]  # If its a moment, have it go in at 45 degree angle, as
                    vv[i] = f[numVar[0], j]  # No circle with arrow exist
            else:
                nodeC = nodeCoor[numVar[i, 0], :]  # Same but for if more then 1 force exists
                xx[i] = nodeC[0]
                yy[i] = nodeC[1]
                j = numVar[i, 1]
                if j == 0:
                    uu[i] = f[numVar[i, 0], j]
                elif j == 1:
                    vv[i] = f[numVar[i, 0], j]
                elif j == 2:
                    uu[i] = f[numVar[i, 0], j]
                    vv[i] = f[numVar[i, 0], j]
        xxx = np.zeros([countR, 1])
        yyy = np.zeros([countR, 1])
        uuu = np.zeros([countR, 1])
        vvv = np.zeros([countR, 1])

        for i in range(countR):  # Generally but for reactionary forces only
            if countR == 1:
                nodeC = nodeCoor[numVarR[0], :]
                xxx[i] = nodeC[0]
                yyy[i] = nodeC[1]
                j = numVarR[1]
                if j == 0:
                    uuu[i] = r[numVarR[0], j]
                elif j == 1:
                    vvv[i] = r[numVarR[0], j]
                elif j == 2:
                    uuu[i] = r[numVarR[0], j]
                    vvv[i] = r[numVarR[0], j]
            else:
                nodeC = nodeCoor[numVarR[i, 0], :]
                xxx[i] = nodeC[0]
                yyy[i] = nodeC[1]
                j = numVarR[i, 1]
                if j == 0:
                    uuu[i] = r[numVarR[i, 0], j]
                elif j == 1:
                    vvv[i] = r[numVarR[i, 0], j]
                elif j == 2:
                    uuu[i] = r[numVarR[i, 0], j]
                    vvv[i] = r[numVarR[i, 0], j]

        forceScale = forceScale + 3  # Conversion from N to kN in plots
        if showForces == 'true' and showReactions == 'true':
            xxx = xxx - uuu * 10 ** (-forceScale)
            yyy = yyy - vvv * 10 ** (-forceScale)
            xx = np.vstack([xx, xxx])  # Add the force and reactions together if so is requested
            yy = np.vstack([yy, yyy])
            uu = np.vstack([uu, uuu])
            vv = np.vstack([vv, vvv])
        elif showForces == 'false' and showReactions == 'true':  # If you only want reactions, override forces
            xxx = xxx - uuu * 10 ** (-forceScale)
            yyy = yyy - vvv * 10 ** (-forceScale)
            xx = xxx
            yy = yyy
            uu = uuu
            vv = vvv
        # As the uu variables are standard for forces, no need to update if only they should be plotted

        # Create the figures for forces. This cannot be done in reverse because class scatter does not contain arg. quiver
        fig1 = ff.create_quiver(xx, yy, uu * 10 ** (-forceScale + 1), vv * 10 ** (-forceScale + 1))
        fig2 = ff.create_quiver(xx, yy, uu * 10 ** (-forceScale + 1), vv * 10 ** (-forceScale + 1))
        fig3 = ff.create_quiver(xx, yy, uu * 10 ** (-forceScale + 1), vv * 10 ** (-forceScale + 1))
        fig4 = ff.create_quiver(xx, yy, uu * 10 ** (-forceScale + 1), vv * 10 ** (-forceScale + 1))
        for d in fig1.data:  # Add all nessesary traces for the quivers
            subplots.add_trace(go.Scatter(x=d['x'], y=d['y']),
                               row=1, col=1)
        # Afterwards add the scatters as traces. This is OK apparently????
        subplots.add_trace(go.Scatter(x=x1, y=y1, name="Original nodes", line  # Plot figure 1 (Geometry)
        =dict(color='blue', width=10), marker=dict(size=5, color='white')), row=1, col=1)
        subplots.add_trace(go.Scatter(x=xDisp, y=yDisp, name="Displaced elements in m", mode="lines+markers",line  # Plot figure 1 (Geometry)
        =dict(color='orange', width=10), marker=dict(size=10, color='white')), row=1, col=1)
        subplots.add_trace(go.Scatter(x=xDisp, y=yDisp, name="Node Numbers", mode="text", text=nodeText,  # Only add note text...
                  textposition="bottom center", textfont=dict(family="AU bold", size=15, color="Black")), row=1, col=1)
        subplots.add_trace(go.Scatter(x=xDisp, y=yDisp, name="Element Numbers", mode="text", text=elemText, # Only add element text
                  textposition="top right", textfont=dict(family="AU bold", size=15, color="Black")), row=1, col=1)

        for d in fig2.data:
            subplots.add_trace(go.Scatter(x=d['x'], y=d['y']),
                               row=1, col=2)
        subplots.add_trace(go.Scatter(x=x1, y=y1, name="Elements", mode="lines+markers+text", line
        =dict(color='blue', width=5), marker=dict(size=5, color='white')), row=1, col=2)
        subplots.add_trace(go.Scatter(x=Ne[:, 0], y=Ne[:, 1], name="Normal Force (kN)", mode="lines+markers+text", line  # Plot normal
        =dict(color='yellow', width=2)), row=1, col=2)
        for d in fig3.data:
            subplots.add_trace(go.Scatter(x=d['x'], y=d['y']),
                               row=2, col=1)
        subplots.add_trace(go.Scatter(x=x1, y=y1, name="Elements", mode="lines+markers+text", line
        =dict(color='blue', width=5), marker=dict(size=5, color='white')), row=2, col=1)
        subplots.add_trace(go.Scatter(x=Qe[:, 0], y=Qe[:, 1], name="Shear Force (kN)", mode="lines+markers+text", line  # Plot shear
        =dict(color='red', width=2)), row=2, col=1)
        for d in fig4.data:
            subplots.add_trace(go.Scatter(x=d['x'], y=d['y']),
                               row=2, col=2)
        subplots.add_trace(go.Scatter(x=x1, y=y1, name="Elements", mode="lines+markers+text", line
        =dict(color='blue', width=5), marker=dict(size=5, color='white')), row=2, col=2)
        subplots.add_trace(go.Scatter(x=Me[:, 0], y=Me[:, 1], name="Bending moment kN*m", mode="lines+markers+text", line  # Plot moments in fig 4
        =dict(color='green', width=2)), row=2, col=2)
        subplots.update_layout(title_text="Force distribution in elements from Timoshenko theory 2D FEM program")

        subplots.show()  # Show the figures
# End of document
# Debugging case
# print(1000*1000/(48* E[0] * Ibeam[1]))